import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { SecurityProvider } from "@/context/SecurityContext";
import { WalletProvider } from "@/context/WalletContext";
import SecurityGate from "./security-gate";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen
        name="deposit"
        options={{ presentation: "modal", headerShown: false }}
      />
      <Stack.Screen
        name="transfer"
        options={{ presentation: "modal", headerShown: false }}
      />
      <Stack.Screen
        name="exchange"
        options={{ presentation: "modal", headerShown: false }}
      />
      <Stack.Screen
        name="add-card"
        options={{ presentation: "modal", headerShown: false }}
      />
      <Stack.Screen
        name="card-detail"
        options={{ presentation: "modal", headerShown: false }}
      />
      <Stack.Screen
        name="crypto-transfer"
        options={{ presentation: "modal", headerShown: false }}
      />
    </Stack>
  );
}

function AppWithSecurity() {
  const [unlocked, setUnlocked] = useState(false);

  if (!unlocked) {
    return <SecurityGate onUnlocked={() => setUnlocked(true)} />;
  }
  return <RootLayoutNav />;
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <SecurityProvider>
            <WalletProvider>
              <GestureHandlerRootView style={{ flex: 1 }}>
                <AppWithSecurity />
              </GestureHandlerRootView>
            </WalletProvider>
          </SecurityProvider>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
