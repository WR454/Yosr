import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import OTPModal from "@/components/OTPModal";
import Colors from "@/constants/colors";
import { useWallet } from "@/context/WalletContext";

const HIGH_VALUE_THRESHOLD = 500;

const SAUDI_BANKS = [
  { key: "anb", name: "Arab National Bank", nameAr: "البنك العربي الوطني", isPrimary: true },
  { key: "alrajhi", name: "Al Rajhi Bank", nameAr: "مصرف الراجحي", isPrimary: false },
  { key: "snb", name: "SNB", nameAr: "البنك الأهلي السعودي", isPrimary: false },
  { key: "sab", name: "Saudi Awwal Bank", nameAr: "البنك السعودي الأول", isPrimary: false },
  { key: "riyad", name: "Riyad Bank", nameAr: "بنك الرياض", isPrimary: false },
  { key: "alinma", name: "Alinma Bank", nameAr: "مصرف الإنماء", isPrimary: false },
  { key: "bsf", name: "Banque Saudi Fransi", nameAr: "البنك السعودي الفرنسي", isPrimary: false },
  { key: "bjaz", name: "Bank AlJazira", nameAr: "بنك الجزيرة", isPrimary: false },
  { key: "albilad", name: "Bank Albilad", nameAr: "بنك البلاد", isPrimary: false },
];

export default function TransferScreen() {
  const insets = useSafeAreaInsets();
  const { wallet, transferLocal, t } = useWallet();
  const [amount, setAmount] = useState("");
  const [iban, setIban] = useState("");
  const [recipientName, setRecipientName] = useState("");
  const [selectedBank, setSelectedBank] = useState("");
  const [note, setNote] = useState("");
  const [showBanks, setShowBanks] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const pendingTransferRef = useRef<{
    parsed: number;
    bankName: string;
  } | null>(null);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const selectedBankData = SAUDI_BANKS.find((b) => b.key === selectedBank);

  const executeTransfer = (parsed: number, bankName: string) => {
    const success = transferLocal(parsed, iban, recipientName, bankName, note);
    if (success) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert(
        t("Transfer Successful!", "تم التحويل بنجاح!"),
        t(
          `${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR sent to ${recipientName}`,
          `تم إرسال ${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} ريال إلى ${recipientName}`
        ),
        [{ text: "OK", onPress: () => router.back() }]
      );
    } else {
      Alert.alert(
        t("Transfer Failed", "فشل التحويل"),
        t("Insufficient balance.", "الرصيد غير كافٍ.")
      );
    }
  };

  const handleOtpSuccess = () => {
    setShowOtp(false);
    if (pendingTransferRef.current) {
      const { parsed, bankName } = pendingTransferRef.current;
      pendingTransferRef.current = null;
      executeTransfer(parsed, bankName);
    }
  };

  const handleTransfer = () => {
    if (!amount || !iban || !recipientName || !selectedBank) {
      Alert.alert(
        t("Missing Information", "معلومات ناقصة"),
        t("Please fill all required fields", "يرجى تعبئة جميع الحقول المطلوبة")
      );
      return;
    }
    const parsed = parseFloat(amount);
    if (!parsed || parsed <= 0) {
      Alert.alert(t("Invalid Amount", "مبلغ غير صالح"), t("Enter a valid amount", "أدخل مبلغاً صحيحاً"));
      return;
    }
    if (parsed > wallet.sarBalance) {
      Alert.alert(t("Insufficient Balance", "رصيد غير كافٍ"), t("You don't have enough SAR balance", "رصيدك بالريال غير كافٍ"));
      return;
    }
    const bankName = selectedBankData ? t(selectedBankData.name, selectedBankData.nameAr) : "";

    if (parsed >= HIGH_VALUE_THRESHOLD) {
      pendingTransferRef.current = { parsed, bankName };
      setShowOtp(true);
      return;
    }

    Alert.alert(
      t("Confirm Transfer", "تأكيد التحويل"),
      t(
        `Transfer ${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR to ${recipientName} (${bankName})?`,
        `تحويل ${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} ريال إلى ${recipientName} (${bankName})؟`
      ),
      [
        { text: t("Cancel", "إلغاء"), style: "cancel" },
        {
          text: t("Transfer", "تحويل"),
          onPress: () => {
            const success = transferLocal(parsed, iban, recipientName, bankName, note);
            if (success) {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              Alert.alert(
                t("Transfer Successful!", "تم التحويل بنجاح!"),
                t(
                  `${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR sent to ${recipientName}`,
                  `تم إرسال ${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} ريال إلى ${recipientName}`
                ),
                [{ text: "OK", onPress: () => router.back() }]
              );
            } else {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
              Alert.alert(t("Transfer Failed", "فشل التحويل"), t("Please check your balance and try again", "تحقق من رصيدك وحاول مرة أخرى"));
            }
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Feather name="x" size={22} color={Colors.light.text} />
        </Pressable>
        <Text style={styles.title}>{t("Local Transfer", "تحويل محلي")}</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 20 }]}
        keyboardShouldPersistTaps="handled"
      >
        {/* Balance Badge */}
        <View style={styles.balanceBadge}>
          <Ionicons name="wallet-outline" size={16} color={Colors.light.tint} />
          <Text style={styles.balanceText}>
            {t("Available:", "المتاح:")}{" "}
            <Text style={styles.balanceAmount}>
              {wallet.sarBalance.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR
            </Text>
          </Text>
        </View>

        {/* Amount */}
        <Text style={styles.fieldLabel}>{t("Amount (SAR)", "المبلغ (ريال)")}</Text>
        <View style={styles.amountContainer}>
          <Text style={styles.currencyPrefix}>SAR</Text>
          <TextInput
            style={styles.amountInput}
            placeholder="0.00"
            placeholderTextColor={Colors.light.textMuted}
            keyboardType="decimal-pad"
            value={amount}
            onChangeText={setAmount}
          />
        </View>

        {/* Recipient Name */}
        <Text style={styles.fieldLabel}>{t("Recipient Name", "اسم المستفيد")}</Text>
        <TextInput
          style={styles.input}
          placeholder={t("Full name", "الاسم الكامل")}
          placeholderTextColor={Colors.light.textMuted}
          value={recipientName}
          onChangeText={setRecipientName}
        />

        {/* IBAN */}
        <Text style={styles.fieldLabel}>{t("IBAN", "رقم الآيبان")}</Text>
        <TextInput
          style={styles.input}
          placeholder="SA00 0000 0000 0000 0000 0000"
          placeholderTextColor={Colors.light.textMuted}
          value={iban}
          onChangeText={(text) => setIban(text.toUpperCase())}
          autoCapitalize="characters"
          maxLength={29}
        />

        {/* Bank Selection */}
        <Text style={styles.fieldLabel}>{t("Bank", "البنك")}</Text>
        <Pressable
          style={styles.bankSelector}
          onPress={() => setShowBanks(!showBanks)}
        >
          {selectedBankData ? (
            <Text style={styles.bankSelected}>
              {t(selectedBankData.name, selectedBankData.nameAr)}
            </Text>
          ) : (
            <Text style={styles.bankPlaceholder}>
              {t("Select bank", "اختر البنك")}
            </Text>
          )}
          <Feather
            name={showBanks ? "chevron-up" : "chevron-down"}
            size={18}
            color={Colors.light.textSecondary}
          />
        </Pressable>

        {showBanks && (
          <View style={styles.bankList}>
            {SAUDI_BANKS.map((bank) => (
              <Pressable
                key={bank.key}
                style={[
                  styles.bankItem,
                  selectedBank === bank.key && styles.bankItemActive,
                ]}
                onPress={() => {
                  Haptics.selectionAsync();
                  setSelectedBank(bank.key);
                  setShowBanks(false);
                }}
              >
                <View style={styles.bankItemLeft}>
                  <Text
                    style={[
                      styles.bankItemText,
                      selectedBank === bank.key && styles.bankItemTextActive,
                    ]}
                  >
                    {t(bank.name, bank.nameAr)}
                  </Text>
                  {bank.isPrimary && (
                    <View style={styles.primaryBadge}>
                      <Text style={styles.primaryBadgeText}>
                        {t("Primary", "الرئيسي")}
                      </Text>
                    </View>
                  )}
                </View>
                {selectedBank === bank.key && (
                  <Feather name="check" size={16} color={Colors.light.tint} />
                )}
              </Pressable>
            ))}
          </View>
        )}

        {/* Note */}
        <Text style={styles.fieldLabel}>{t("Note (Optional)", "ملاحظة (اختياري)")}</Text>
        <TextInput
          style={[styles.input, styles.noteInput]}
          placeholder={t("Add a note...", "أضف ملاحظة...")}
          placeholderTextColor={Colors.light.textMuted}
          value={note}
          onChangeText={setNote}
          multiline
          numberOfLines={3}
        />

        {/* Transfer Button */}
        <Pressable
          style={({ pressed }) => [styles.transferBtn, { opacity: pressed ? 0.85 : 1 }]}
          onPress={handleTransfer}
        >
          <LinearGradient
            colors={[Colors.light.tint, Colors.light.tintDark]}
            style={styles.transferBtnGradient}
          >
            <Feather name="send" size={20} color="#fff" />
            <Text style={styles.transferBtnText}>{t("Transfer", "تحويل")}</Text>
          </LinearGradient>
        </Pressable>

        {/* Security Note */}
        {parseFloat(amount) >= HIGH_VALUE_THRESHOLD && (
          <View style={styles.securityNote}>
            <Ionicons name="shield-checkmark" size={14} color={Colors.light.tint} />
            <Text style={styles.securityNoteText}>
              {t(
                "Transfers ≥500 SAR require 2FA verification",
                "التحويلات ≥500 ريال تتطلب التحقق بخطوتين"
              )}
            </Text>
          </View>
        )}
      </ScrollView>

      <OTPModal
        visible={showOtp}
        purpose="Bank Transfer"
        purposeAr="تحويل بنكي"
        amount={pendingTransferRef.current?.parsed}
        onSuccess={handleOtpSuccess}
        onCancel={() => {
          setShowOtp(false);
          pendingTransferRef.current = null;
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.light.background },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.light.backgroundTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 4, gap: 4 },
  balanceBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: Colors.light.tint + "12",
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  balanceText: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
  },
  balanceAmount: {
    fontFamily: "Inter_700Bold",
    color: Colors.light.tint,
  },
  fieldLabel: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
    marginTop: 12,
    marginBottom: 8,
  },
  amountContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderWidth: 2,
    borderColor: Colors.light.tint + "30",
    gap: 10,
  },
  currencyPrefix: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.tint,
    fontFamily: "Inter_700Bold",
  },
  amountInput: {
    flex: 1,
    fontSize: 28,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
    padding: 0,
  },
  input: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    color: Colors.light.text,
    fontFamily: "Inter_400Regular",
    borderWidth: 1.5,
    borderColor: Colors.light.border,
  },
  noteInput: {
    height: 80,
    textAlignVertical: "top",
  },
  bankSelector: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1.5,
    borderColor: Colors.light.border,
  },
  bankSelected: {
    fontSize: 15,
    color: Colors.light.text,
    fontFamily: "Inter_500Medium",
  },
  bankPlaceholder: {
    fontSize: 15,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
  },
  bankList: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: Colors.light.border,
    overflow: "hidden",
    marginTop: 4,
  },
  bankItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: Colors.light.borderLight,
  },
  bankItemActive: {
    backgroundColor: Colors.light.tint + "08",
  },
  bankItemLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flex: 1,
  },
  bankItemText: {
    fontSize: 14,
    color: Colors.light.text,
    fontFamily: "Inter_400Regular",
  },
  bankItemTextActive: {
    color: Colors.light.tint,
    fontFamily: "Inter_600SemiBold",
  },
  primaryBadge: {
    backgroundColor: Colors.light.tint + "18",
    borderRadius: 6,
    paddingHorizontal: 7,
    paddingVertical: 2,
  },
  primaryBadgeText: {
    fontSize: 10,
    color: Colors.light.tint,
    fontFamily: "Inter_600SemiBold",
  },
  transferBtn: {
    borderRadius: 16,
    overflow: "hidden",
    marginTop: 16,
  },
  transferBtnGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 18,
  },
  transferBtnText: {
    fontSize: 17,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  securityNote: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: Colors.light.tint + "12",
    borderRadius: 10,
    padding: 10,
    marginTop: 4,
  },
  securityNoteText: {
    fontSize: 12,
    color: Colors.light.tint,
    fontFamily: "Inter_500Medium",
    flex: 1,
  },
});
