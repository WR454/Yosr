import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { useWallet } from "@/context/WalletContext";

const BRANDS = [
  { key: "mada", label: "mada", color: "#00B050", bg: "#E6F7EE" },
  { key: "visa", label: "VISA", color: "#1A1F71", bg: "#EEF0FF" },
  { key: "mastercard", label: "MC", color: "#EB001B", bg: "#FFEEEE" },
] as const;

const TYPES = [
  { key: "virtual", en: "Virtual", ar: "افتراضية", icon: "monitor" as const },
  { key: "physical", en: "Physical", ar: "مادية", icon: "credit-card" as const },
] as const;

const CARD_COLORS = [
  "#1A7A4A",
  "#0F1E14",
  "#C9A84C",
  "#2563EB",
  "#9333EA",
  "#1C1C1E",
];

export default function AddCardScreen() {
  const insets = useSafeAreaInsets();
  const { addCard, t } = useWallet();
  const [holderName, setHolderName] = useState("");
  const [selectedBrand, setSelectedBrand] = useState<"mada" | "visa" | "mastercard">("mada");
  const [selectedType, setSelectedType] = useState<"virtual" | "physical">("virtual");
  const [selectedColor, setSelectedColor] = useState(CARD_COLORS[0]);
  const [currency, setCurrency] = useState("SAR");

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const handleAddCard = () => {
    if (!holderName.trim()) {
      Alert.alert(t("Missing Name", "الاسم مفقود"), t("Please enter cardholder name", "أدخل اسم حامل البطاقة"));
      return;
    }

    const lastFour = String(Math.floor(1000 + Math.random() * 9000));
    const now = new Date();
    addCard({
      type: selectedType,
      brand: selectedBrand,
      lastFour,
      holderName: holderName.trim(),
      expiryMonth: now.getMonth() + 1,
      expiryYear: now.getFullYear() + 3,
      isDefault: false,
      color: selectedColor,
      currency,
    });

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert(
      t("Card Added!", "تمت إضافة البطاقة!"),
      t(
        `Your ${selectedType} ${selectedBrand.toUpperCase()} card has been added successfully.`,
        `تمت إضافة بطاقة ${selectedBrand.toUpperCase()} ${selectedType === "virtual" ? "الافتراضية" : "المادية"} بنجاح.`
      ),
      [{ text: "OK", onPress: () => router.back() }]
    );
  };

  const previewBrand = BRANDS.find((b) => b.key === selectedBrand)!;

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Feather name="x" size={22} color={Colors.light.text} />
        </Pressable>
        <Text style={styles.title}>{t("Add Card", "إضافة بطاقة")}</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 20 }]}
        keyboardShouldPersistTaps="handled"
      >
        {/* Preview Card */}
        <LinearGradient
          colors={[selectedColor, selectedColor + "CC"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.previewCard}
        >
          <View style={styles.cardDecor1} />
          <View style={styles.cardDecor2} />
          <View style={styles.cardTop}>
            <View style={styles.chip} />
            <View style={[styles.cardTypeBadge, { backgroundColor: "rgba(255,255,255,0.15)" }]}>
              <Text style={styles.cardTypeText}>{selectedType.toUpperCase()}</Text>
            </View>
          </View>
          <Text style={styles.previewNumber}>•••• •••• •••• ••••</Text>
          <View style={styles.cardBottom}>
            <View>
              <Text style={styles.cardHolderLabel}>CARD HOLDER</Text>
              <Text style={styles.cardHolderName}>{holderName || "Your Name"}</Text>
            </View>
            <Text style={[styles.brandText, { color: previewBrand.color === "#1A1F71" ? "#fff" : previewBrand.color === "#00B050" ? "#00FF7F" : "#FF5F00" }]}>
              {previewBrand.label}
            </Text>
          </View>
        </LinearGradient>

        {/* Card Holder Name */}
        <Text style={styles.fieldLabel}>{t("Cardholder Name", "اسم حامل البطاقة")}</Text>
        <TextInput
          style={styles.input}
          placeholder={t("Full name (as on card)", "الاسم الكامل")}
          placeholderTextColor={Colors.light.textMuted}
          value={holderName}
          onChangeText={setHolderName}
          autoCapitalize="words"
        />

        {/* Card Type */}
        <Text style={styles.fieldLabel}>{t("Card Type", "نوع البطاقة")}</Text>
        <View style={styles.typeRow}>
          {TYPES.map((type) => (
            <Pressable
              key={type.key}
              style={[
                styles.typeBtn,
                selectedType === type.key && styles.typeBtnActive,
              ]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedType(type.key);
              }}
            >
              <Feather
                name={type.icon}
                size={20}
                color={selectedType === type.key ? Colors.light.tint : Colors.light.textSecondary}
              />
              <Text
                style={[
                  styles.typeBtnText,
                  selectedType === type.key && styles.typeBtnTextActive,
                ]}
              >
                {t(type.en, type.ar)}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Brand */}
        <Text style={styles.fieldLabel}>{t("Network", "الشبكة")}</Text>
        <View style={styles.brandRow}>
          {BRANDS.map((brand) => (
            <Pressable
              key={brand.key}
              style={[
                styles.brandBtn,
                selectedBrand === brand.key && {
                  borderColor: brand.color,
                  backgroundColor: brand.bg,
                },
              ]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedBrand(brand.key);
              }}
            >
              <Text style={[styles.brandBtnText, { color: brand.color }]}>
                {brand.label}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Card Color */}
        <Text style={styles.fieldLabel}>{t("Card Color", "لون البطاقة")}</Text>
        <View style={styles.colorRow}>
          {CARD_COLORS.map((color) => (
            <Pressable
              key={color}
              style={[
                styles.colorBtn,
                { backgroundColor: color },
                selectedColor === color && styles.colorBtnActive,
              ]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedColor(color);
              }}
            >
              {selectedColor === color && (
                <Feather name="check" size={14} color="#fff" />
              )}
            </Pressable>
          ))}
        </View>

        {/* Currency */}
        <Text style={styles.fieldLabel}>{t("Currency", "العملة")}</Text>
        <View style={styles.currencyRow}>
          {["SAR", "USD", "EUR"].map((cur) => (
            <Pressable
              key={cur}
              style={[styles.currencyBtn, currency === cur && styles.currencyBtnActive]}
              onPress={() => {
                Haptics.selectionAsync();
                setCurrency(cur);
              }}
            >
              <Text style={[styles.currencyBtnText, currency === cur && styles.currencyBtnTextActive]}>
                {cur}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Add Button */}
        <Pressable
          style={({ pressed }) => [styles.addBtn, { opacity: pressed ? 0.85 : 1 }]}
          onPress={handleAddCard}
        >
          <LinearGradient
            colors={[Colors.light.tint, Colors.light.tintDark]}
            style={styles.addBtnGradient}
          >
            <Ionicons name="card" size={20} color="#fff" />
            <Text style={styles.addBtnText}>{t("Add Card", "إضافة البطاقة")}</Text>
          </LinearGradient>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.light.background },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.light.backgroundTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 4,
  },
  previewCard: {
    height: 200,
    borderRadius: 22,
    padding: 22,
    marginBottom: 24,
    overflow: "hidden",
    position: "relative",
    justifyContent: "space-between",
  },
  cardDecor1: {
    position: "absolute",
    width: 180,
    height: 180,
    borderRadius: 90,
    backgroundColor: "rgba(255,255,255,0.06)",
    top: -50,
    right: -30,
  },
  cardDecor2: {
    position: "absolute",
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: "rgba(255,255,255,0.04)",
    bottom: -40,
    left: 20,
  },
  cardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  chip: {
    width: 34,
    height: 26,
    borderRadius: 5,
    backgroundColor: "rgba(255,215,0,0.5)",
  },
  cardTypeBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  cardTypeText: {
    fontSize: 9,
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.5,
  },
  previewNumber: {
    fontSize: 16,
    color: "rgba(255,255,255,0.9)",
    fontFamily: "Inter_500Medium",
    letterSpacing: 3,
  },
  cardBottom: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
  },
  cardHolderLabel: {
    fontSize: 9,
    color: "rgba(255,255,255,0.5)",
    fontFamily: "Inter_400Regular",
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  cardHolderName: {
    fontSize: 13,
    color: "#fff",
    fontFamily: "Inter_600SemiBold",
  },
  brandText: {
    fontSize: 16,
    fontWeight: "800",
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  fieldLabel: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 10,
    marginTop: 8,
  },
  input: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    color: Colors.light.text,
    fontFamily: "Inter_400Regular",
    borderWidth: 1.5,
    borderColor: Colors.light.border,
    marginBottom: 4,
  },
  typeRow: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 4,
  },
  typeBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 2,
    borderColor: Colors.light.border,
  },
  typeBtnActive: {
    borderColor: Colors.light.tint,
    backgroundColor: Colors.light.tint + "10",
  },
  typeBtnText: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
    color: Colors.light.textSecondary,
  },
  typeBtnTextActive: {
    color: Colors.light.tint,
    fontFamily: "Inter_600SemiBold",
  },
  brandRow: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 4,
  },
  brandBtn: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 2,
    borderColor: Colors.light.border,
  },
  brandBtnText: {
    fontSize: 16,
    fontWeight: "800",
    fontFamily: "Inter_700Bold",
  },
  colorRow: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 4,
    flexWrap: "wrap",
  },
  colorBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
  },
  colorBtnActive: {
    borderWidth: 3,
    borderColor: "#fff",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  currencyRow: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 20,
  },
  currencyBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 2,
    borderColor: Colors.light.border,
  },
  currencyBtnActive: {
    borderColor: Colors.light.tint,
    backgroundColor: Colors.light.tint + "10",
  },
  currencyBtnText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: Colors.light.textSecondary,
  },
  currencyBtnTextActive: {
    color: Colors.light.tint,
  },
  addBtn: {
    borderRadius: 16,
    overflow: "hidden",
  },
  addBtnGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 18,
  },
  addBtnText: {
    fontSize: 17,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
});
