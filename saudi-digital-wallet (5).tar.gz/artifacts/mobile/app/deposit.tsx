import { Feather, Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { useWallet } from "@/context/WalletContext";

const METHODS = [
  {
    key: "bank_transfer",
    en: "Bank Transfer",
    ar: "تحويل بنكي",
    desc_en: "Transfer from any Saudi bank",
    desc_ar: "حوّل من أي بنك سعودي",
    icon: <Feather name="building" size={22} color="#2563EB" />,
    bg: "#EEF2FF",
  },
  {
    key: "stcpay",
    en: "STC Pay",
    ar: "STC Pay",
    desc_en: "Fast transfer via STC Pay",
    desc_ar: "تحويل سريع عبر STC Pay",
    icon: <MaterialCommunityIcons name="cellphone" size={22} color="#800080" />,
    bg: "#F5E8FF",
  },
  {
    key: "card",
    en: "Debit/Credit Card",
    ar: "بطاقة ائتمان / بنكية",
    desc_en: "Pay with mada, Visa, Mastercard",
    desc_ar: "ادفع بمدى أو فيزا أو ماستركارد",
    icon: <Ionicons name="card" size={22} color={Colors.light.tint} />,
    bg: "#E8F5EE",
  },
  {
    key: "apple_pay",
    en: "Apple Pay",
    ar: "Apple Pay",
    desc_en: "Quick & secure with Apple Pay",
    desc_ar: "سريع وآمن مع Apple Pay",
    icon: <MaterialCommunityIcons name="apple" size={22} color="#000" />,
    bg: "#F3F4F6",
  },
];

const QUICK_AMOUNTS = [500, 1000, 2000, 5000, 10000];

export default function DepositScreen() {
  const insets = useSafeAreaInsets();
  const { depositFunds, wallet, t } = useWallet();
  const [amount, setAmount] = useState("");
  const [selectedMethod, setSelectedMethod] = useState("bank_transfer");

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const handleDeposit = () => {
    const parsed = parseFloat(amount);
    if (!parsed || parsed <= 0) {
      Alert.alert(t("Invalid Amount", "مبلغ غير صالح"), t("Please enter a valid amount", "أدخل مبلغاً صحيحاً"));
      return;
    }
    if (parsed < 10) {
      Alert.alert(t("Minimum Amount", "الحد الأدنى"), t("Minimum deposit is 10 SAR", "الحد الأدنى للإيداع هو 10 ريال"));
      return;
    }

    Alert.alert(
      t("Confirm Deposit", "تأكيد الإيداع"),
      t(
        `Deposit ${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR via ${METHODS.find((m) => m.key === selectedMethod)?.en}?`,
        `إيداع ${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} ريال عبر ${METHODS.find((m) => m.key === selectedMethod)?.ar}؟`
      ),
      [
        { text: t("Cancel", "إلغاء"), style: "cancel" },
        {
          text: t("Confirm", "تأكيد"),
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            depositFunds(parsed, selectedMethod);
            Alert.alert(
              t("Deposit Successful!", "تم الإيداع بنجاح!"),
              t(
                `${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR has been added to your wallet.`,
                `تمت إضافة ${parsed.toLocaleString("en-SA", { minimumFractionDigits: 2 })} ريال إلى محفظتك.`
              ),
              [{ text: "OK", onPress: () => router.back() }]
            );
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Feather name="x" size={22} color={Colors.light.text} />
        </Pressable>
        <Text style={styles.title}>{t("Add Money", "إضافة رصيد")}</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 20 }]}
        keyboardShouldPersistTaps="handled"
      >
        {/* Balance */}
        <LinearGradient
          colors={["#1A7A4A", "#0D5533"]}
          style={styles.balanceBox}
        >
          <Text style={styles.balanceLabel}>{t("Current Balance", "الرصيد الحالي")}</Text>
          <Text style={styles.balanceValue}>
            {wallet.sarBalance.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR
          </Text>
        </LinearGradient>

        {/* Amount Input */}
        <Text style={styles.sectionLabel}>{t("Enter Amount", "أدخل المبلغ")}</Text>
        <View style={styles.amountContainer}>
          <Text style={styles.currencyPrefix}>SAR</Text>
          <TextInput
            style={styles.amountInput}
            placeholder="0.00"
            placeholderTextColor={Colors.light.textMuted}
            keyboardType="decimal-pad"
            value={amount}
            onChangeText={setAmount}
            autoFocus
          />
        </View>

        {/* Quick Amounts */}
        <View style={styles.quickAmounts}>
          {QUICK_AMOUNTS.map((amt) => (
            <Pressable
              key={amt}
              style={[
                styles.quickAmountChip,
                amount === String(amt) && styles.quickAmountActive,
              ]}
              onPress={() => {
                Haptics.selectionAsync();
                setAmount(String(amt));
              }}
            >
              <Text
                style={[
                  styles.quickAmountText,
                  amount === String(amt) && styles.quickAmountTextActive,
                ]}
              >
                {amt >= 1000 ? `${amt / 1000}K` : amt}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Methods */}
        <Text style={styles.sectionLabel}>{t("Payment Method", "طريقة الدفع")}</Text>
        <View style={styles.methods}>
          {METHODS.map((method) => (
            <Pressable
              key={method.key}
              style={[
                styles.methodItem,
                selectedMethod === method.key && styles.methodItemActive,
              ]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedMethod(method.key);
              }}
            >
              <View style={[styles.methodIcon, { backgroundColor: method.bg }]}>
                {method.icon}
              </View>
              <View style={styles.methodInfo}>
                <Text style={styles.methodName}>{t(method.en, method.ar)}</Text>
                <Text style={styles.methodDesc}>{t(method.desc_en, method.desc_ar)}</Text>
              </View>
              {selectedMethod === method.key ? (
                <View style={styles.radioActive}>
                  <View style={styles.radioInner} />
                </View>
              ) : (
                <View style={styles.radio} />
              )}
            </Pressable>
          ))}
        </View>

        {/* Deposit Button */}
        <Pressable
          style={({ pressed }) => [styles.depositBtn, { opacity: pressed ? 0.85 : 1 }]}
          onPress={handleDeposit}
        >
          <LinearGradient
            colors={[Colors.light.tint, Colors.light.tintDark]}
            style={styles.depositBtnGradient}
          >
            <Feather name="arrow-down-circle" size={20} color="#fff" />
            <Text style={styles.depositBtnText}>{t("Add Money", "إضافة رصيد")}</Text>
          </LinearGradient>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.light.backgroundTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  scroll: { flex: 1 },
  content: {
    paddingHorizontal: 20,
    paddingTop: 4,
  },
  balanceBox: {
    borderRadius: 18,
    padding: 20,
    marginBottom: 24,
    alignItems: "center",
  },
  balanceLabel: {
    fontSize: 13,
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
    marginBottom: 6,
  },
  balanceValue: {
    fontSize: 28,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  sectionLabel: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 10,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  amountContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 16,
    paddingHorizontal: 20,
    paddingVertical: 16,
    marginBottom: 14,
    borderWidth: 2,
    borderColor: Colors.light.tint + "30",
    gap: 12,
  },
  currencyPrefix: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.light.tint,
    fontFamily: "Inter_700Bold",
  },
  amountInput: {
    flex: 1,
    fontSize: 32,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
    padding: 0,
  },
  quickAmounts: {
    flexDirection: "row",
    gap: 8,
    marginBottom: 24,
    flexWrap: "wrap",
  },
  quickAmountChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 1.5,
    borderColor: Colors.light.border,
  },
  quickAmountActive: {
    backgroundColor: Colors.light.tint + "15",
    borderColor: Colors.light.tint,
  },
  quickAmountText: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
  },
  quickAmountTextActive: {
    color: Colors.light.tint,
  },
  methods: {
    gap: 10,
    marginBottom: 24,
  },
  methodItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 16,
    padding: 16,
    borderWidth: 2,
    borderColor: "transparent",
  },
  methodItemActive: {
    borderColor: Colors.light.tint,
    backgroundColor: Colors.light.tint + "08",
  },
  methodIcon: {
    width: 46,
    height: 46,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  methodInfo: {
    flex: 1,
  },
  methodName: {
    fontSize: 15,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  methodDesc: {
    fontSize: 12,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: Colors.light.border,
  },
  radioActive: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: Colors.light.tint,
    alignItems: "center",
    justifyContent: "center",
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.light.tint,
  },
  depositBtn: {
    borderRadius: 16,
    overflow: "hidden",
  },
  depositBtnGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 18,
  },
  depositBtnText: {
    fontSize: 17,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
});
