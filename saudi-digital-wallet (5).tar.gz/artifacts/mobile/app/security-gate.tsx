import { Feather, Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { useSecurity } from "@/context/SecurityContext";
import { APP_BRAND } from "@/context/WalletContext";

interface SecurityGateProps {
  onUnlocked: () => void;
}

export default function SecurityGate({ onUnlocked }: SecurityGateProps) {
  const insets = useSafeAreaInsets();
  const {
    isBiometricAvailable,
    isBiometricEnrolled,
    unlockWithBiometric,
  } = useSecurity();
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);
  const [attempts, setAttempts] = useState(0);

  useEffect(() => {
    attemptBiometric();
  }, []);

  const attemptBiometric = async () => {
    setLoading(true);
    setFailed(false);
    const success = await unlockWithBiometric();
    setLoading(false);
    if (success) {
      onUnlocked();
    } else {
      setFailed(true);
      setAttempts((a) => a + 1);
    }
  };

  const canUseBiometric =
    Platform.OS !== "web" && isBiometricAvailable && isBiometricEnrolled;

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <LinearGradient
      colors={["#0D5533", "#1A7A4A", "#2EAD6B"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[styles.container, { paddingTop: topPad, paddingBottom: bottomPad }]}
    >
      <View style={styles.decor1} />
      <View style={styles.decor2} />

      <View style={styles.content}>
        {/* Brand */}
        <View style={styles.brandContainer}>
          <View style={styles.brandCircle}>
            <Text style={styles.brandText}>{APP_BRAND}</Text>
          </View>
          <Text style={styles.appName}>Saudi Digital Wallet</Text>
          <Text style={styles.appNameAr}>المحفظة الرقمية السعودية</Text>
        </View>

        {/* Lock Icon */}
        <View style={styles.lockContainer}>
          {loading ? (
            <ActivityIndicator size="large" color="rgba(255,255,255,0.9)" />
          ) : (
            <View style={styles.lockCircle}>
              <Ionicons
                name={failed ? "lock-closed" : "finger-print"}
                size={56}
                color={failed ? "rgba(255,255,255,0.5)" : "rgba(255,255,255,0.95)"}
              />
            </View>
          )}
        </View>

        {/* Status Text */}
        <Text style={styles.statusTitle}>
          {loading
            ? "Verifying..."
            : failed
            ? "Authentication Required"
            : "Biometric Lock"}
        </Text>
        <Text style={styles.statusSubtitle}>
          {loading
            ? "Please verify your identity"
            : failed
            ? attempts >= 3
              ? "Too many attempts. Please try again."
              : "Authentication failed. Please try again."
            : canUseBiometric
            ? "Use Face ID or fingerprint to unlock"
            : "Tap to unlock your wallet"}
        </Text>

        {/* Security Badge */}
        <View style={styles.securityBadge}>
          <Ionicons name="shield-checkmark" size={14} color="rgba(255,255,255,0.8)" />
          <Text style={styles.securityBadgeText}>AES-256 Encrypted · 2FA Protected</Text>
        </View>

        {/* Action Button */}
        {!loading && (
          <Pressable
            style={({ pressed }) => [
              styles.unlockBtn,
              { opacity: pressed ? 0.85 : 1 },
            ]}
            onPress={attemptBiometric}
          >
            <Ionicons
              name={canUseBiometric ? "finger-print" : "lock-open"}
              size={20}
              color={Colors.light.tint}
            />
            <Text style={styles.unlockBtnText}>
              {canUseBiometric ? "Unlock with Biometrics" : "Unlock Wallet"}
            </Text>
          </Pressable>
        )}

        {/* Skip on web / dev */}
        {(Platform.OS === "web" || __DEV__) && (
          <Pressable style={styles.skipBtn} onPress={onUnlocked}>
            <Feather name="arrow-right" size={14} color="rgba(255,255,255,0.5)" />
            <Text style={styles.skipText}>Skip (Dev Mode)</Text>
          </Pressable>
        )}
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Ionicons name="lock-closed" size={12} color="rgba(255,255,255,0.4)" />
        <Text style={styles.footerText}>
          End-to-end encrypted · SSL/TLS secured
        </Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: "relative",
    overflow: "hidden",
  },
  decor1: {
    position: "absolute",
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: "rgba(255,255,255,0.05)",
    top: -80,
    right: -80,
  },
  decor2: {
    position: "absolute",
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: "rgba(255,255,255,0.04)",
    bottom: 100,
    left: -50,
  },
  content: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 40,
    gap: 16,
  },
  brandContainer: {
    alignItems: "center",
    gap: 10,
    marginBottom: 20,
  },
  brandCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.3)",
  },
  brandText: {
    fontSize: 26,
    fontWeight: "800",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  appName: {
    fontSize: 22,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  appNameAr: {
    fontSize: 16,
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
  },
  lockContainer: {
    width: 110,
    height: 110,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  lockCircle: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: "rgba(255,255,255,0.1)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.2)",
  },
  statusTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
    textAlign: "center",
  },
  statusSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
  securityBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 7,
    marginTop: 4,
  },
  securityBadgeText: {
    fontSize: 11,
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_500Medium",
  },
  unlockBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#fff",
    borderRadius: 18,
    paddingHorizontal: 32,
    paddingVertical: 16,
    marginTop: 8,
    shadowColor: "rgba(0,0,0,0.3)",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 10,
    elevation: 6,
  },
  unlockBtnText: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.light.tint,
    fontFamily: "Inter_700Bold",
  },
  skipBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 8,
    padding: 8,
  },
  skipText: {
    fontSize: 12,
    color: "rgba(255,255,255,0.4)",
    fontFamily: "Inter_400Regular",
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingBottom: 10,
  },
  footerText: {
    fontSize: 11,
    color: "rgba(255,255,255,0.4)",
    fontFamily: "Inter_400Regular",
  },
});
