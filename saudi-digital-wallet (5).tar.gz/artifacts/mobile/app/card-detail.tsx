import { Feather, Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { useWallet } from "@/context/WalletContext";

export default function CardDetailScreen() {
  const insets = useSafeAreaInsets();
  const { cards, transactions, t, freezeCard } = useWallet();
  const params = useLocalSearchParams<{ cardId?: string }>();
  const [showFull, setShowFull] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const card = params.cardId
    ? cards.find((c) => c.id === params.cardId)
    : cards.find((c) => c.isDefault) ?? cards[0];

  if (!card) {
    return (
      <View style={[styles.container, { paddingTop: topPad }]}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Feather name="x" size={22} color={Colors.light.text} />
        </Pressable>
        <View style={styles.emptyState}>
          <Ionicons name="card-outline" size={50} color={Colors.light.border} />
          <Text style={styles.emptyTitle}>{t("No Card Found", "لم يتم العثور على البطاقة")}</Text>
        </View>
      </View>
    );
  }

  const gradients: Record<string, [string, string]> = {
    "#1A7A4A": ["#1A7A4A", "#0D5533"],
    "#0F1E14": ["#1C2E22", "#0F1E14"],
    "#C9A84C": ["#C9A84C", "#A0822E"],
    "#1C1C1E": ["#2C2C2E", "#1C1C1E"],
    "#2563EB": ["#2563EB", "#1D4ED8"],
    "#9333EA": ["#9333EA", "#7E22CE"],
  };
  const gradient = card.isFrozen
    ? (["#6B7280", "#374151"] as [string, string])
    : (gradients[card.color] ?? ["#1A7A4A", "#0D5533"]);

  const cardTxs = transactions.slice(0, 8);

  const handleAddToAppleWallet = () => {
    Alert.alert(
      t("Add to Apple Wallet", "إضافة إلى Apple Wallet"),
      t(
        `Your ${card.brand.toUpperCase()} card ending in ${card.lastFour} has been added to Apple Wallet.`,
        `تم إضافة بطاقة ${card.brand.toUpperCase()} المنتهية بـ ${card.lastFour} إلى Apple Wallet.`
      ),
      [{ text: t("Done", "تم") }]
    );
  };

  const handleAddToGooglePay = () => {
    Alert.alert(
      t("Add to Google Pay", "إضافة إلى Google Pay"),
      t(
        `Your ${card.brand.toUpperCase()} card ending in ${card.lastFour} has been added to Google Pay.`,
        `تم إضافة بطاقة ${card.brand.toUpperCase()} المنتهية بـ ${card.lastFour} إلى Google Pay.`
      ),
      [{ text: t("Done", "تم") }]
    );
  };

  const handleFreezeToggle = () => {
    const willFreeze = !card.isFrozen;
    Alert.alert(
      willFreeze ? t("Freeze Card", "تجميد البطاقة") : t("Unfreeze Card", "إلغاء تجميد البطاقة"),
      willFreeze
        ? t("All transactions will be blocked while the card is frozen.", "سيتم حظر جميع المعاملات أثناء تجميد البطاقة.")
        : t("The card will be reactivated.", "سيتم إعادة تفعيل البطاقة."),
      [
        { text: t("Cancel", "إلغاء"), style: "cancel" },
        {
          text: willFreeze ? t("Freeze", "تجميد") : t("Unfreeze", "إلغاء التجميد"),
          style: willFreeze ? "destructive" : "default",
          onPress: () => freezeCard(card.id, willFreeze),
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Pressable style={styles.closeBtn} onPress={() => router.back()}>
          <Feather name="x" size={22} color={Colors.light.text} />
        </Pressable>
        <Text style={styles.title}>{t("Card Details", "تفاصيل البطاقة")}</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 20 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Card Preview */}
        <LinearGradient
          colors={gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.cardPreview}
        >
          <View style={styles.cardDecor1} />
          <View style={styles.cardDecor2} />
          {card.isFrozen && (
            <View style={styles.frozenBanner}>
              <MaterialCommunityIcons name="snowflake" size={14} color="rgba(255,255,255,0.9)" />
              <Text style={styles.frozenBannerText}>{t("FROZEN", "مجمدة")}</Text>
            </View>
          )}
          <View style={styles.cardTop}>
            <View style={styles.chip} />
            <Text style={styles.cardTypeBadge}>
              {card.type.toUpperCase()}
            </Text>
          </View>
          <Text style={styles.cardNumber}>
            {showFull
              ? `4532 8891 ${card.lastFour.substring(0, 2)}12 ${card.lastFour}`
              : `•••• •••• •••• ${card.lastFour}`}
          </Text>
          <View style={styles.cardBottom}>
            <View>
              <Text style={styles.cardLabel}>CARD HOLDER</Text>
              <Text style={styles.cardHolder}>{card.holderName}</Text>
            </View>
            <View>
              <Text style={styles.cardLabel}>EXPIRES</Text>
              <Text style={styles.cardHolder}>
                {String(card.expiryMonth).padStart(2, "0")}/{card.expiryYear}
              </Text>
            </View>
            <Text
              style={[
                styles.brandLogo,
                {
                  color:
                    card.brand === "visa"
                      ? "#fff"
                      : card.brand === "mada"
                      ? "#00FF7F"
                      : "#FF5F00",
                },
              ]}
            >
              {card.brand === "visa"
                ? "VISA"
                : card.brand === "mastercard"
                ? "MC"
                : "mada"}
            </Text>
          </View>
        </LinearGradient>

        {/* Show / Hide Number */}
        <Pressable
          style={styles.showNumberBtn}
          onPress={() => setShowFull(!showFull)}
        >
          <Feather
            name={showFull ? "eye-off" : "eye"}
            size={16}
            color={Colors.light.tint}
          />
          <Text style={styles.showNumberText}>
            {showFull
              ? t("Hide Card Number", "إخفاء رقم البطاقة")
              : t("Show Card Number", "عرض رقم البطاقة")}
          </Text>
        </Pressable>

        {/* Mobile Wallet Buttons */}
        <View style={styles.walletButtons}>
          {Platform.OS !== "android" && (
            <Pressable
              style={({ pressed }) => [
                styles.appleWalletBtn,
                { opacity: pressed ? 0.85 : 1 },
              ]}
              onPress={handleAddToAppleWallet}
            >
              <Ionicons name="logo-apple" size={18} color="#fff" />
              <View>
                <Text style={styles.walletBtnSub}>{t("Add to", "أضف إلى")}</Text>
                <Text style={styles.walletBtnMain}>Apple Wallet</Text>
              </View>
            </Pressable>
          )}
          <Pressable
            style={({ pressed }) => [
              styles.googlePayBtn,
              { opacity: pressed ? 0.85 : 1 },
            ]}
            onPress={handleAddToGooglePay}
          >
            <MaterialCommunityIcons name="google-pay" size={24} color="#fff" />
            <View>
              <Text style={[styles.walletBtnSub, { color: "rgba(255,255,255,0.7)" }]}>
                {t("Add to", "أضف إلى")}
              </Text>
              <Text style={[styles.walletBtnMain, { color: "#fff" }]}>Google Pay</Text>
            </View>
          </Pressable>
        </View>

        {/* Card Information */}
        <View style={styles.infoCard}>
          <Text style={styles.infoCardTitle}>{t("Card Information", "معلومات البطاقة")}</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>{t("Card Type", "نوع البطاقة")}</Text>
            <Text style={styles.infoValue}>
              {card.type === "virtual" ? t("Virtual", "افتراضية") : t("Physical", "مادية")}
            </Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>{t("Network", "الشبكة")}</Text>
            <Text style={styles.infoValue}>{card.brand.toUpperCase()}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>{t("Currency", "العملة")}</Text>
            <Text style={styles.infoValue}>{card.currency}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>{t("Status", "الحالة")}</Text>
            <Pressable
              style={[
                styles.statusBadge,
                { backgroundColor: card.isFrozen ? "#EFF6FF" : "#E8F5EE" },
              ]}
              onPress={handleFreezeToggle}
            >
              <View
                style={[
                  styles.statusDot,
                  { backgroundColor: card.isFrozen ? "#60A5FA" : Colors.light.positive },
                ]}
              />
              <Text
                style={[
                  styles.statusText,
                  { color: card.isFrozen ? "#60A5FA" : Colors.light.positive },
                ]}
              >
                {card.isFrozen ? t("Frozen — Tap to unfreeze", "مجمدة — اضغط لإلغاء التجميد") : t("Active", "نشطة")}
              </Text>
            </Pressable>
          </View>
          {card.isDefault && (
            <>
              <View style={styles.divider} />
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>{t("Default Card", "البطاقة الافتراضية")}</Text>
                <View style={styles.defaultBadge}>
                  <Ionicons name="star" size={12} color={Colors.light.gold} />
                  <Text style={styles.defaultText}>{t("Yes", "نعم")}</Text>
                </View>
              </View>
            </>
          )}
        </View>

        {/* Spending Limits */}
        <View style={styles.limitsCard}>
          <Text style={styles.infoCardTitle}>{t("Spending Limits", "حدود الإنفاق")}</Text>
          <View style={styles.limitRow}>
            <View style={styles.limitItem}>
              <Text style={styles.limitLabel}>{t("Daily", "يومي")}</Text>
              <Text style={styles.limitValue}>50,000 SAR</Text>
              <View style={styles.limitBar}>
                <View style={[styles.limitFill, { width: "30%" }]} />
              </View>
              <Text style={styles.limitUsed}>15,000 / 50,000</Text>
            </View>
            <View style={styles.limitItem}>
              <Text style={styles.limitLabel}>{t("Monthly", "شهري")}</Text>
              <Text style={styles.limitValue}>200,000 SAR</Text>
              <View style={styles.limitBar}>
                <View style={[styles.limitFill, { width: "15%" }]} />
              </View>
              <Text style={styles.limitUsed}>30,000 / 200,000</Text>
            </View>
          </View>
        </View>

        {/* Recent Transactions */}
        <Text style={styles.sectionTitle}>
          {t("Recent Transactions", "المعاملات الأخيرة")}
        </Text>
        <View style={styles.txList}>
          {cardTxs.length === 0 ? (
            <View style={styles.noTx}>
              <Text style={styles.noTxText}>{t("No transactions yet", "لا توجد معاملات بعد")}</Text>
            </View>
          ) : (
            cardTxs.map((tx, idx) => {
              const isCredit = tx.type === "deposit" || tx.type === "transfer_in";
              return (
                <View key={tx.id}>
                  <View style={styles.txRow}>
                    <View style={styles.txDot} />
                    <View style={styles.txInfo}>
                      <Text style={styles.txDesc} numberOfLines={1}>
                        {tx.description}
                      </Text>
                      <Text style={styles.txDate}>
                        {new Date(tx.createdAt).toLocaleDateString("en-SA", {
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </Text>
                    </View>
                    <Text
                      style={[
                        styles.txAmount,
                        { color: isCredit ? Colors.light.positive : Colors.light.negative },
                      ]}
                    >
                      {isCredit ? "+" : "-"}
                      {tx.amount.toLocaleString("en-SA", { minimumFractionDigits: 2 })} {tx.currency}
                    </Text>
                  </View>
                  {idx < cardTxs.length - 1 && <View style={styles.divider} />}
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.light.background },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  closeBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.light.backgroundTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.light.backgroundTertiary,
    alignItems: "center",
    justifyContent: "center",
    margin: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  content: { paddingHorizontal: 20, paddingTop: 4 },
  cardPreview: {
    height: 200,
    borderRadius: 22,
    padding: 22,
    marginBottom: 12,
    overflow: "hidden",
    position: "relative",
    justifyContent: "space-between",
  },
  cardDecor1: {
    position: "absolute",
    width: 180,
    height: 180,
    borderRadius: 90,
    backgroundColor: "rgba(255,255,255,0.06)",
    top: -50,
    right: -30,
  },
  cardDecor2: {
    position: "absolute",
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: "rgba(255,255,255,0.04)",
    bottom: -40,
    left: 20,
  },
  frozenBanner: {
    position: "absolute",
    top: 12,
    right: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "rgba(96,165,250,0.3)",
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  frozenBannerText: {
    fontSize: 9,
    color: "rgba(255,255,255,0.9)",
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  cardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  chip: {
    width: 34,
    height: 26,
    borderRadius: 5,
    backgroundColor: "rgba(255,215,0,0.5)",
  },
  cardTypeBadge: {
    fontSize: 9,
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.5,
    backgroundColor: "rgba(255,255,255,0.15)",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  cardNumber: {
    fontSize: 16,
    color: "rgba(255,255,255,0.9)",
    fontFamily: "Inter_500Medium",
    letterSpacing: 3,
  },
  cardBottom: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
  },
  cardLabel: {
    fontSize: 9,
    color: "rgba(255,255,255,0.5)",
    fontFamily: "Inter_400Regular",
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  cardHolder: {
    fontSize: 11,
    color: "#fff",
    fontFamily: "Inter_600SemiBold",
  },
  brandLogo: {
    fontSize: 16,
    fontWeight: "800",
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  showNumberBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    alignSelf: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.light.tint + "12",
    borderRadius: 20,
    marginBottom: 16,
  },
  showNumberText: {
    fontSize: 13,
    color: Colors.light.tint,
    fontFamily: "Inter_500Medium",
  },
  walletButtons: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 16,
  },
  appleWalletBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#000",
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  googlePayBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#1a73e8",
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  walletBtnSub: {
    fontSize: 10,
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
  },
  walletBtnMain: {
    fontSize: 13,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  infoCard: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 18,
    padding: 16,
    marginBottom: 14,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
  },
  infoCardTitle: {
    fontSize: 15,
    fontWeight: "600",
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 14,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
  },
  infoValue: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  divider: {
    height: 1,
    backgroundColor: Colors.light.borderLight,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
  },
  statusText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  defaultBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  defaultText: {
    fontSize: 13,
    color: Colors.light.gold,
    fontFamily: "Inter_600SemiBold",
  },
  limitsCard: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 18,
    padding: 16,
    marginBottom: 18,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
  },
  limitRow: {
    flexDirection: "row",
    gap: 16,
  },
  limitItem: { flex: 1 },
  limitLabel: {
    fontSize: 12,
    color: Colors.light.textMuted,
    fontFamily: "Inter_500Medium",
    marginBottom: 4,
  },
  limitValue: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
    marginBottom: 8,
  },
  limitBar: {
    height: 6,
    backgroundColor: Colors.light.borderLight,
    borderRadius: 3,
    overflow: "hidden",
    marginBottom: 4,
  },
  limitFill: {
    height: "100%",
    backgroundColor: Colors.light.tint,
    borderRadius: 3,
  },
  limitUsed: {
    fontSize: 11,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 10,
  },
  txList: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 18,
    padding: 4,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
  },
  txRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
  },
  txDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.light.tint,
  },
  txInfo: { flex: 1 },
  txDesc: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.light.text,
    fontFamily: "Inter_500Medium",
  },
  txDate: {
    fontSize: 11,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  txAmount: {
    fontSize: 13,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
  },
  noTx: {
    padding: 20,
    alignItems: "center",
  },
  noTxText: {
    fontSize: 14,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
  },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
});
