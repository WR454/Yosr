import {
  Feather,
  Ionicons,
  MaterialCommunityIcons,
} from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { useWallet } from "@/context/WalletContext";

type Currency = "SAR" | "BTC" | "ETH" | "USDT";

const CURRENCIES: {
  symbol: Currency;
  name: string;
  nameAr: string;
  color: string;
  icon: string;
}[] = [
  { symbol: "SAR", name: "Saudi Riyal", nameAr: "ريال سعودي", color: "#1A7A4A", icon: "﷼" },
  { symbol: "BTC", name: "Bitcoin", nameAr: "بيتكوين", color: "#F7931A", icon: "₿" },
  { symbol: "ETH", name: "Ethereum", nameAr: "إيثيريوم", color: "#627EEA", icon: "Ξ" },
  { symbol: "USDT", name: "Tether", nameAr: "تيثر", color: "#26A17B", icon: "₮" },
];

export default function ExchangeScreen() {
  const insets = useSafeAreaInsets();
  const { wallet, exchangeRates, exchangeCurrency, t } = useWallet();
  const [fromCurrency, setFromCurrency] = useState<Currency>("SAR");
  const [toCurrency, setToCurrency] = useState<Currency>("BTC");
  const [amount, setAmount] = useState("");
  const [isSwapping, setIsSwapping] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const getBalance = (symbol: Currency) => {
    switch (symbol) {
      case "SAR": return wallet.sarBalance;
      case "BTC": return wallet.btcBalance;
      case "ETH": return wallet.ethBalance;
      case "USDT": return wallet.usdtBalance;
    }
  };

  const getRate = (from: Currency, to: Currency): number => {
    if (from === to) return 1;
    if (from === "SAR" && to === "BTC") return 1 / exchangeRates.btcSar;
    if (from === "SAR" && to === "ETH") return 1 / exchangeRates.ethSar;
    if (from === "SAR" && to === "USDT") return 1 / exchangeRates.usdtSar;
    if (from === "BTC" && to === "SAR") return exchangeRates.btcSar;
    if (from === "ETH" && to === "SAR") return exchangeRates.ethSar;
    if (from === "USDT" && to === "SAR") return exchangeRates.usdtSar;
    return 1;
  };

  const parsedAmount = parseFloat(amount) || 0;
  const rate = getRate(fromCurrency, toCurrency);
  const receiveAmount = parsedAmount * rate;

  const handleSwap = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
    setAmount("");
  };

  const handleExchange = () => {
    if (!parsedAmount || parsedAmount <= 0) {
      Alert.alert(t("Invalid Amount", "مبلغ غير صالح"), t("Please enter a valid amount", "أدخل مبلغاً صحيحاً"));
      return;
    }
    const balance = getBalance(fromCurrency);
    if (parsedAmount > balance) {
      Alert.alert(t("Insufficient Balance", "رصيد غير كافٍ"), t("You don't have enough balance", "رصيدك غير كافٍ"));
      return;
    }

    Alert.alert(
      t("Confirm Exchange", "تأكيد التحويل"),
      t(
        `Exchange ${parsedAmount} ${fromCurrency} to ${receiveAmount.toFixed(6)} ${toCurrency}?`,
        `تحويل ${parsedAmount} ${fromCurrency} إلى ${receiveAmount.toFixed(6)} ${toCurrency}؟`
      ),
      [
        { text: t("Cancel", "إلغاء"), style: "cancel" },
        {
          text: t("Confirm", "تأكيد"),
          onPress: () => {
            const result = exchangeCurrency(fromCurrency, toCurrency, parsedAmount);
            if (result.success) {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              Alert.alert(
                t("Success!", "تم بنجاح!"),
                t(
                  `You received ${result.receivedAmount.toFixed(6)} ${toCurrency}`,
                  `استلمت ${result.receivedAmount.toFixed(6)} ${toCurrency}`
                )
              );
              setAmount("");
            } else {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
              Alert.alert(t("Exchange Failed", "فشل التحويل"), t("Please try again", "حاول مرة أخرى"));
            }
          },
        },
      ]
    );
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingTop: topPad + 8, paddingBottom: 120 }]}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={styles.title}>{t("Exchange", "التحويل")}</Text>
      <Text style={styles.subtitle}>
        {t("Swap between currencies instantly", "حوّل بين العملات فوراً")}
      </Text>

      {/* Exchange Rates Banner */}
      <View style={styles.ratesBanner}>
        <View style={styles.rateItem}>
          <Text style={styles.rateLabel}>BTC/SAR</Text>
          <Text style={styles.rateValue}>
            {exchangeRates.btcSar.toLocaleString("en-SA")}
          </Text>
        </View>
        <View style={styles.rateDivider} />
        <View style={styles.rateItem}>
          <Text style={styles.rateLabel}>ETH/SAR</Text>
          <Text style={styles.rateValue}>
            {exchangeRates.ethSar.toLocaleString("en-SA")}
          </Text>
        </View>
        <View style={styles.rateDivider} />
        <View style={styles.rateItem}>
          <Text style={styles.rateLabel}>USDT/SAR</Text>
          <Text style={styles.rateValue}>{exchangeRates.usdtSar}</Text>
        </View>
      </View>

      {/* Exchange Card */}
      <View style={styles.exchangeCard}>
        {/* From */}
        <View style={styles.exchangeSection}>
          <Text style={styles.exchangeLabel}>{t("From", "من")}</Text>
          <View style={styles.currencySelector}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
              {CURRENCIES.map((c) => (
                <Pressable
                  key={c.symbol}
                  style={[
                    styles.currencyChip,
                    fromCurrency === c.symbol && styles.currencyChipActive,
                    fromCurrency === c.symbol && { borderColor: c.color },
                  ]}
                  onPress={() => {
                    if (c.symbol !== toCurrency) {
                      Haptics.selectionAsync();
                      setFromCurrency(c.symbol);
                    }
                  }}
                >
                  <Text style={[styles.currencyChipIcon, { color: c.color }]}>
                    {c.icon}
                  </Text>
                  <Text
                    style={[
                      styles.currencyChipLabel,
                      fromCurrency === c.symbol && { color: c.color, fontFamily: "Inter_600SemiBold" },
                    ]}
                  >
                    {c.symbol}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
          <View style={styles.amountRow}>
            <TextInput
              style={styles.amountInput}
              placeholder="0.00"
              placeholderTextColor={Colors.light.textMuted}
              keyboardType="decimal-pad"
              value={amount}
              onChangeText={setAmount}
            />
            <Text style={styles.amountCurrency}>{fromCurrency}</Text>
          </View>
          <Text style={styles.balanceHint}>
            {t("Balance:", "الرصيد:")}{" "}
            {getBalance(fromCurrency).toLocaleString("en-SA", {
              minimumFractionDigits: fromCurrency === "SAR" ? 2 : 6,
              maximumFractionDigits: fromCurrency === "SAR" ? 2 : 6,
            })}{" "}
            {fromCurrency}
          </Text>
        </View>

        {/* Swap Button */}
        <Pressable style={styles.swapBtn} onPress={handleSwap}>
          <LinearGradient
            colors={[Colors.light.tint, Colors.light.tintDark]}
            style={styles.swapBtnGradient}
          >
            <Ionicons name="swap-vertical" size={22} color="#fff" />
          </LinearGradient>
        </Pressable>

        {/* To */}
        <View style={styles.exchangeSection}>
          <Text style={styles.exchangeLabel}>{t("To", "إلى")}</Text>
          <View style={styles.currencySelector}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
              {CURRENCIES.map((c) => (
                <Pressable
                  key={c.symbol}
                  style={[
                    styles.currencyChip,
                    toCurrency === c.symbol && styles.currencyChipActive,
                    toCurrency === c.symbol && { borderColor: c.color },
                  ]}
                  onPress={() => {
                    if (c.symbol !== fromCurrency) {
                      Haptics.selectionAsync();
                      setToCurrency(c.symbol);
                    }
                  }}
                >
                  <Text style={[styles.currencyChipIcon, { color: c.color }]}>
                    {c.icon}
                  </Text>
                  <Text
                    style={[
                      styles.currencyChipLabel,
                      toCurrency === c.symbol && { color: c.color, fontFamily: "Inter_600SemiBold" },
                    ]}
                  >
                    {c.symbol}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
          <View style={styles.receiveRow}>
            <Text style={styles.receiveAmount}>
              {parsedAmount > 0
                ? receiveAmount.toFixed(toCurrency === "SAR" ? 2 : 6)
                : "0.00"}
            </Text>
            <Text style={styles.amountCurrency}>{toCurrency}</Text>
          </View>
          <Text style={styles.balanceHint}>
            {t("Balance:", "الرصيد:")}{" "}
            {getBalance(toCurrency).toLocaleString("en-SA", {
              minimumFractionDigits: toCurrency === "SAR" ? 2 : 6,
              maximumFractionDigits: toCurrency === "SAR" ? 2 : 6,
            })}{" "}
            {toCurrency}
          </Text>
        </View>

        {/* Rate Info */}
        {parsedAmount > 0 && (
          <View style={styles.rateInfo}>
            <Feather name="info" size={14} color={Colors.light.textMuted} />
            <Text style={styles.rateInfoText}>
              1 {fromCurrency} ={" "}
              {rate.toFixed(fromCurrency === "SAR" ? 6 : 2)} {toCurrency}
            </Text>
          </View>
        )}
      </View>

      {/* Exchange Button */}
      <Pressable
        style={({ pressed }) => [
          styles.exchangeBtn,
          { opacity: pressed ? 0.85 : 1 },
          !amount && styles.exchangeBtnDisabled,
        ]}
        onPress={handleExchange}
        disabled={!amount}
      >
        <LinearGradient
          colors={amount ? [Colors.light.tint, Colors.light.tintDark] : ["#ccc", "#bbb"]}
          style={styles.exchangeBtnGradient}
        >
          <Text style={styles.exchangeBtnText}>{t("Exchange Now", "تحويل الآن")}</Text>
          <Ionicons name="arrow-forward" size={20} color="#fff" />
        </LinearGradient>
      </Pressable>

      {/* Crypto Transfer */}
      <Pressable
        style={styles.cryptoTransferCard}
        onPress={() => router.push("/crypto-transfer")}
      >
        <View style={styles.cryptoTransferLeft}>
          <View style={styles.cryptoTransferIcon}>
            <MaterialCommunityIcons name="bitcoin" size={24} color="#F7931A" />
          </View>
          <View>
            <Text style={styles.cryptoTransferTitle}>
              {t("Send Crypto", "إرسال كريبتو")}
            </Text>
            <Text style={styles.cryptoTransferSub}>
              {t("Transfer to external wallet", "تحويل إلى محفظة خارجية")}
            </Text>
          </View>
        </View>
        <Feather name="arrow-right" size={18} color={Colors.light.textSecondary} />
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  content: {
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
    marginBottom: 20,
  },
  ratesBanner: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 16,
    padding: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
  },
  rateItem: {
    flex: 1,
    alignItems: "center",
  },
  rateLabel: {
    fontSize: 11,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
    marginBottom: 2,
  },
  rateValue: {
    fontSize: 13,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  rateDivider: {
    width: 1,
    height: 30,
    backgroundColor: Colors.light.border,
  },
  exchangeCard: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 24,
    padding: 20,
    marginBottom: 20,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 4,
  },
  exchangeSection: {
    marginBottom: 8,
  },
  exchangeLabel: {
    fontSize: 12,
    color: Colors.light.textMuted,
    fontFamily: "Inter_500Medium",
    marginBottom: 10,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  currencySelector: {
    marginBottom: 14,
  },
  currencyChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: Colors.light.border,
    backgroundColor: Colors.light.background,
  },
  currencyChipActive: {
    backgroundColor: Colors.light.backgroundSecondary,
  },
  currencyChipIcon: {
    fontSize: 14,
    fontWeight: "700",
  },
  currencyChipLabel: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_500Medium",
  },
  amountRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  amountInput: {
    flex: 1,
    fontSize: 32,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
    padding: 0,
  },
  amountCurrency: {
    fontSize: 18,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
  },
  balanceHint: {
    fontSize: 12,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
    marginTop: 4,
  },
  swapBtn: {
    alignSelf: "center",
    marginVertical: 12,
  },
  swapBtnGradient: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  receiveRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  receiveAmount: {
    flex: 1,
    fontSize: 32,
    fontWeight: "700",
    color: Colors.light.tint,
    fontFamily: "Inter_700Bold",
  },
  rateInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.light.borderLight,
  },
  rateInfoText: {
    fontSize: 12,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
  },
  exchangeBtn: {
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 16,
  },
  exchangeBtnDisabled: {
    opacity: 0.5,
  },
  exchangeBtnGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 18,
  },
  exchangeBtnText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  cryptoTransferCard: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 16,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
  },
  cryptoTransferLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  cryptoTransferIcon: {
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: "#FEF3C7",
    alignItems: "center",
    justifyContent: "center",
  },
  cryptoTransferTitle: {
    fontSize: 15,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  cryptoTransferSub: {
    fontSize: 12,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
});
