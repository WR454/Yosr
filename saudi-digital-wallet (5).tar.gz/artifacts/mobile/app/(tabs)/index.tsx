import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Dimensions,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import {
  ACCOUNT_HOLDER,
  ACCOUNT_HOLDER_AR,
  ACCOUNT_IBAN,
  ACCOUNT_NUMBER,
  APP_BRAND,
  PRIMARY_BANK,
  PRIMARY_BANK_AR,
  PRIMARY_BANK_SHORT,
  useWallet,
} from "@/context/WalletContext";

const { width } = Dimensions.get("window");

function BrandLogo() {
  return (
    <View style={styles.brandLogo}>
      <Text style={styles.brandLogoText}>{APP_BRAND}</Text>
    </View>
  );
}

function QuickAction({
  icon,
  label,
  labelAr,
  onPress,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  labelAr: string;
  onPress: () => void;
  color: string;
}) {
  const { t } = useWallet();
  return (
    <Pressable
      style={({ pressed }) => [
        styles.quickAction,
        { opacity: pressed ? 0.7 : 1 },
      ]}
      onPress={onPress}
    >
      <View style={[styles.quickActionIcon, { backgroundColor: color + "18" }]}>
        {icon}
      </View>
      <Text style={styles.quickActionLabel}>{t(label, labelAr)}</Text>
    </Pressable>
  );
}

function CryptoRow({
  name,
  symbol,
  balance,
  sarValue,
  change,
  color,
  onPress,
}: {
  name: string;
  symbol: string;
  balance: number;
  sarValue: number;
  change: number;
  color: string;
  onPress: () => void;
}) {
  const isPositive = change >= 0;
  return (
    <Pressable
      style={({ pressed }) => [styles.cryptoRow, { opacity: pressed ? 0.75 : 1 }]}
      onPress={onPress}
    >
      <View style={[styles.cryptoIcon, { backgroundColor: color + "20" }]}>
        <Text style={[styles.cryptoSymbolIcon, { color }]}>
          {symbol === "BTC" ? "₿" : symbol === "ETH" ? "Ξ" : "₮"}
        </Text>
      </View>
      <View style={styles.cryptoInfo}>
        <Text style={styles.cryptoName}>{name}</Text>
        <Text style={styles.cryptoBalance}>
          {balance.toFixed(symbol === "USDT" ? 2 : 6)} {symbol}
        </Text>
      </View>
      <View style={styles.cryptoValues}>
        <Text style={styles.cryptoSarValue}>
          {sarValue.toLocaleString("en-SA", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}{" "}
          SAR
        </Text>
        <Text
          style={[
            styles.cryptoChange,
            { color: isPositive ? Colors.light.positive : Colors.light.negative },
          ]}
        >
          {isPositive ? "+" : ""}
          {change}%
        </Text>
      </View>
      <Feather name="chevron-right" size={16} color={Colors.light.textMuted} style={{ marginLeft: 4 }} />
    </Pressable>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { wallet, cards, transactions, language, setLanguage, t, exchangeRates } =
    useWallet();
  const [balanceHidden, setBalanceHidden] = useState(false);
  const [ibanVisible, setIbanVisible] = useState(false);

  const defaultCard = cards.find((c) => c.isDefault) || cards[0];
  const recentTxs = transactions.slice(0, 5);

  const handleAction = (route: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push(route as any);
  };

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topPad + 8, paddingBottom: 100 },
      ]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <BrandLogo />
          <View>
            <Text style={styles.greeting}>{t("Good morning,", "صباح الخير،")}</Text>
            <Text style={styles.userName}>
              {language === "ar" ? ACCOUNT_HOLDER_AR : ACCOUNT_HOLDER}
            </Text>
          </View>
        </View>
        <View style={styles.headerActions}>
          <Pressable
            style={styles.langButton}
            onPress={() => setLanguage(language === "en" ? "ar" : "en")}
          >
            <Text style={styles.langText}>{language === "en" ? "عر" : "EN"}</Text>
          </Pressable>
          <Pressable style={styles.notifButton}>
            <Ionicons name="notifications-outline" size={22} color={Colors.light.text} />
            <View style={styles.notifDot} />
          </Pressable>
        </View>
      </View>

      {/* Balance Card */}
      <LinearGradient
        colors={["#1A7A4A", "#0D5533"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.balanceCard}
      >
        <View style={styles.balanceCardDecor1} />
        <View style={styles.balanceCardDecor2} />
        <View style={styles.balanceHeader}>
          <Text style={styles.balanceLabel}>{t("Total Balance", "الرصيد الإجمالي")}</Text>
          <Pressable onPress={() => setBalanceHidden(!balanceHidden)}>
            <Feather
              name={balanceHidden ? "eye-off" : "eye"}
              size={20}
              color="rgba(255,255,255,0.7)"
            />
          </Pressable>
        </View>
        <Text style={styles.balanceAmount}>
          {balanceHidden
            ? "••••••"
            : wallet.sarBalance.toLocaleString("en-SA", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
          <Text style={styles.balanceCurrency}> SAR</Text>
        </Text>
        <Text style={styles.totalPortfolio}>
          {t("Portfolio value:", "قيمة المحفظة:")} {balanceHidden ? "••••••" : wallet.totalSarValue.toLocaleString("en-SA", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} SAR
        </Text>

        {/* IBAN Row */}
        <Pressable style={styles.ibanRow} onPress={() => setIbanVisible(!ibanVisible)}>
          <View style={styles.ibanBankTag}>
            <Text style={styles.ibanBankTagText}>{PRIMARY_BANK_SHORT}</Text>
          </View>
          <Text style={styles.ibanLabel}>{t("IBAN:", "رقم الآيبان:")}</Text>
          <Text style={styles.ibanValue}>
            {ibanVisible ? ACCOUNT_IBAN : "SA•• •••• •••• •••• •••• ••••"}
          </Text>
          <Feather name={ibanVisible ? "eye-off" : "eye"} size={12} color="rgba(255,255,255,0.5)" />
        </Pressable>

        {defaultCard && (
          <View style={styles.cardInfo}>
            <View style={styles.cardChip}>
              <Ionicons name="card" size={14} color="rgba(255,255,255,0.8)" />
            </View>
            <Text style={styles.cardNumber}>•••• {defaultCard.lastFour}</Text>
            <Text style={styles.cardBrand}>{defaultCard.brand.toUpperCase()}</Text>
          </View>
        )}
      </LinearGradient>

      {/* ANB Linked Account */}
      <View style={styles.anbCard}>
        <View style={styles.anbLeft}>
          <View style={styles.anbLogo}>
            <Text style={styles.anbLogoText}>{PRIMARY_BANK_SHORT}</Text>
          </View>
          <View>
            <Text style={styles.anbBankName}>
              {language === "ar" ? PRIMARY_BANK_AR : PRIMARY_BANK}
            </Text>
            <Text style={styles.anbAccNumber}>
              {t("Account No:", "رقم الحساب:")} {ACCOUNT_NUMBER.replace(/(.{4})/g, "$1 ").trim()}
            </Text>
          </View>
        </View>
        <View style={styles.anbRight}>
          <View style={styles.anbLinkedBadge}>
            <View style={styles.anbLinkedDot} />
            <Text style={styles.anbLinkedText}>{t("Linked", "مرتبط")}</Text>
          </View>
          <Pressable onPress={() => handleAction("/transfer")}>
            <Text style={styles.anbTransferText}>{t("Transfer", "تحويل")}</Text>
          </Pressable>
        </View>
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActionsRow}>
        <QuickAction
          icon={<Feather name="arrow-down-circle" size={22} color={Colors.light.tint} />}
          label="Add Money"
          labelAr="إيداع"
          onPress={() => handleAction("/deposit")}
          color={Colors.light.tint}
        />
        <QuickAction
          icon={<Feather name="send" size={22} color="#2563EB" />}
          label="Transfer"
          labelAr="تحويل"
          onPress={() => handleAction("/transfer")}
          color="#2563EB"
        />
        <QuickAction
          icon={<Ionicons name="swap-horizontal" size={22} color="#9333EA" />}
          label="Exchange"
          labelAr="صرف"
          onPress={() => handleAction("/(tabs)/exchange")}
          color="#9333EA"
        />
        <QuickAction
          icon={<Ionicons name="card-outline" size={22} color={Colors.light.gold} />}
          label="Cards"
          labelAr="البطاقات"
          onPress={() => handleAction("/(tabs)/cards")}
          color={Colors.light.gold}
        />
      </View>

      {/* Crypto Portfolio */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t("Digital Assets", "الأصول الرقمية")}</Text>
          <Pressable onPress={() => handleAction("/(tabs)/exchange")}>
            <Text style={styles.seeAll}>{t("Exchange", "صرف")}</Text>
          </Pressable>
        </View>
        <View style={styles.card}>
          <CryptoRow
            name="Bitcoin"
            symbol="BTC"
            balance={wallet.btcBalance}
            sarValue={wallet.btcBalance * exchangeRates.btcSar}
            change={2.4}
            color="#F7931A"
            onPress={() => handleAction("/crypto-transfer")}
          />
          <View style={styles.divider} />
          <CryptoRow
            name="Ethereum"
            symbol="ETH"
            balance={wallet.ethBalance}
            sarValue={wallet.ethBalance * exchangeRates.ethSar}
            change={-1.2}
            color="#627EEA"
            onPress={() => handleAction("/crypto-transfer")}
          />
          <View style={styles.divider} />
          <CryptoRow
            name="Tether"
            symbol="USDT"
            balance={wallet.usdtBalance}
            sarValue={wallet.usdtBalance * exchangeRates.usdtSar}
            change={0.01}
            color="#26A17B"
            onPress={() => handleAction("/crypto-transfer")}
          />
        </View>
      </View>

      {/* Recent Transactions */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            {t("Recent Transactions", "المعاملات الأخيرة")}
          </Text>
          <Pressable onPress={() => handleAction("/(tabs)/history")}>
            <Text style={styles.seeAll}>{t("See all", "عرض الكل")}</Text>
          </Pressable>
        </View>
        <View style={styles.card}>
          {recentTxs.map((tx, idx) => {
            const isCredit =
              tx.type === "deposit" || tx.type === "transfer_in";
            const icon = getTransactionIcon(tx.type);
            const isLast = idx === recentTxs.length - 1;
            return (
              <View key={tx.id}>
                <View style={styles.txRow}>
                  <View
                    style={[styles.txIcon, { backgroundColor: icon.bg }]}
                  >
                    {icon.element}
                  </View>
                  <View style={styles.txInfo}>
                    <Text style={styles.txDesc} numberOfLines={1}>
                      {language === "ar" ? tx.descriptionAr : tx.description}
                    </Text>
                    <Text style={styles.txDate}>
                      {formatDate(tx.createdAt)}
                    </Text>
                  </View>
                  <Text
                    style={[
                      styles.txAmount,
                      {
                        color: isCredit
                          ? Colors.light.positive
                          : Colors.light.negative,
                      },
                    ]}
                  >
                    {isCredit ? "+" : "-"}
                    {tx.amount.toLocaleString("en-SA", {
                      minimumFractionDigits: tx.currency === "BTC" ? 6 : 2,
                      maximumFractionDigits: tx.currency === "BTC" ? 6 : 2,
                    })}{" "}
                    {tx.currency}
                  </Text>
                </View>
                {!isLast && <View style={styles.divider} />}
              </View>
            );
          })}
        </View>
      </View>
    </ScrollView>
  );
}

function getTransactionIcon(type: string) {
  switch (type) {
    case "deposit":
      return {
        bg: "#E8F5EE",
        element: <Feather name="arrow-down-circle" size={18} color="#1A7A4A" />,
      };
    case "transfer_in":
      return {
        bg: "#E8F5EE",
        element: <Feather name="arrow-down-left" size={18} color="#1A7A4A" />,
      };
    case "transfer_out":
      return {
        bg: "#FDECEA",
        element: <Feather name="arrow-up-right" size={18} color="#DC3545" />,
      };
    case "exchange":
      return {
        bg: "#F3E8FF",
        element: <Ionicons name="swap-horizontal" size={18} color="#9333EA" />,
      };
    case "crypto_transfer":
      return {
        bg: "#FEF3C7",
        element: <Feather name="send" size={18} color="#D97706" />,
      };
    default:
      return {
        bg: "#F3F4F6",
        element: <Feather name="activity" size={18} color="#6B7280" />,
      };
  }
}

function formatDate(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return "Yesterday";
  return date.toLocaleDateString("en-SA", { month: "short", day: "numeric" });
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  content: {
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    flex: 1,
  },
  brandLogo: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.light.tint,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: Colors.light.tint,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    elevation: 4,
  },
  brandLogoText: {
    fontSize: 17,
    fontWeight: "800",
    color: "#fff",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
  },
  greeting: {
    fontSize: 12,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
  },
  userName: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
    marginTop: 1,
  },
  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  langButton: {
    backgroundColor: Colors.light.tint + "15",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  langText: {
    fontSize: 13,
    fontWeight: "600",
    color: Colors.light.tint,
    fontFamily: "Inter_600SemiBold",
  },
  notifButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.light.backgroundSecondary,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  notifDot: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.light.error,
    borderWidth: 1.5,
    borderColor: "#fff",
  },
  balanceCard: {
    borderRadius: 24,
    padding: 24,
    marginBottom: 20,
    overflow: "hidden",
    position: "relative",
  },
  balanceCardDecor1: {
    position: "absolute",
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: "rgba(255,255,255,0.05)",
    top: -60,
    right: -40,
  },
  balanceCardDecor2: {
    position: "absolute",
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: "rgba(255,255,255,0.04)",
    bottom: -40,
    left: 20,
  },
  balanceHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 13,
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_500Medium",
  },
  balanceAmount: {
    fontSize: 36,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  balanceCurrency: {
    fontSize: 18,
    color: "rgba(255,255,255,0.8)",
  },
  totalPortfolio: {
    fontSize: 12,
    color: "rgba(255,255,255,0.6)",
    fontFamily: "Inter_400Regular",
    marginBottom: 10,
  },
  ibanRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 7,
    marginBottom: 14,
  },
  ibanBankTag: {
    backgroundColor: Colors.light.gold + "40",
    borderRadius: 5,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  ibanBankTagText: {
    fontSize: 9,
    fontWeight: "800",
    color: Colors.light.goldLight,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.5,
  },
  ibanLabel: {
    fontSize: 11,
    color: "rgba(255,255,255,0.6)",
    fontFamily: "Inter_500Medium",
  },
  ibanValue: {
    fontSize: 11,
    color: "rgba(255,255,255,0.85)",
    fontFamily: "Inter_500Medium",
    flex: 1,
    letterSpacing: 0.5,
  },
  cardInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  cardChip: {
    width: 28,
    height: 28,
    borderRadius: 6,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center",
    justifyContent: "center",
  },
  cardNumber: {
    fontSize: 14,
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_500Medium",
    letterSpacing: 1,
  },
  cardBrand: {
    fontSize: 11,
    color: Colors.light.goldLight,
    fontFamily: "Inter_600SemiBold",
    marginLeft: 4,
  },
  anbCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 16,
    padding: 14,
    marginBottom: 20,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
    borderLeftWidth: 3,
    borderLeftColor: Colors.light.tint,
  },
  anbLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    flex: 1,
  },
  anbLogo: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: Colors.light.tint,
    alignItems: "center",
    justifyContent: "center",
  },
  anbLogoText: {
    fontSize: 12,
    fontWeight: "800",
    color: "#fff",
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.5,
  },
  anbBankName: {
    fontSize: 13,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  anbAccNumber: {
    fontSize: 11,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  anbRight: {
    alignItems: "flex-end",
    gap: 6,
  },
  anbLinkedBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#E8F5EE",
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  anbLinkedDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.light.positive,
  },
  anbLinkedText: {
    fontSize: 11,
    color: Colors.light.positive,
    fontFamily: "Inter_600SemiBold",
  },
  anbTransferText: {
    fontSize: 12,
    color: Colors.light.tint,
    fontFamily: "Inter_600SemiBold",
  },
  quickActionsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  quickAction: {
    alignItems: "center",
    flex: 1,
  },
  quickActionIcon: {
    width: 56,
    height: 56,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  quickActionLabel: {
    fontSize: 11,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_500Medium",
    textAlign: "center",
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  seeAll: {
    fontSize: 13,
    color: Colors.light.tint,
    fontFamily: "Inter_500Medium",
  },
  card: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 18,
    padding: 4,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 2,
  },
  cryptoRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  cryptoIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
  },
  cryptoSymbolIcon: {
    fontSize: 18,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
  },
  cryptoInfo: {
    flex: 1,
  },
  cryptoName: {
    fontSize: 15,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  cryptoBalance: {
    fontSize: 12,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  cryptoValues: {
    alignItems: "flex-end",
  },
  cryptoSarValue: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  cryptoChange: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.light.borderLight,
    marginHorizontal: 14,
  },
  txRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  txIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  txInfo: {
    flex: 1,
  },
  txDesc: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.light.text,
    fontFamily: "Inter_500Medium",
  },
  txDate: {
    fontSize: 12,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  txAmount: {
    fontSize: 14,
    fontWeight: "600",
    fontFamily: "Inter_600SemiBold",
  },
});
