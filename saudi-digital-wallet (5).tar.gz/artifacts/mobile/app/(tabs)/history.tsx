import { Feather, Ionicons } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { Transaction, useWallet } from "@/context/WalletContext";

const FILTERS = [
  { key: "all", en: "All", ar: "الكل" },
  { key: "deposit", en: "Deposits", ar: "الإيداعات" },
  { key: "transfer_out", en: "Transfers", ar: "التحويلات" },
  { key: "exchange", en: "Exchange", ar: "الصرف" },
  { key: "crypto_transfer", en: "Crypto", ar: "كريبتو" },
] as const;

function TransactionItem({ tx }: { tx: Transaction }) {
  const { t, language } = useWallet();
  const isCredit = tx.type === "deposit" || tx.type === "transfer_in";
  const icon = getTransactionIcon(tx.type);

  return (
    <View style={styles.txItem}>
      <View style={[styles.txIcon, { backgroundColor: icon.bg }]}>
        {icon.element}
      </View>
      <View style={styles.txContent}>
        <View style={styles.txTop}>
          <Text style={styles.txDesc} numberOfLines={1}>
            {language === "ar" ? tx.descriptionAr : tx.description}
          </Text>
          <Text
            style={[
              styles.txAmount,
              { color: isCredit ? Colors.light.positive : Colors.light.negative },
            ]}
          >
            {isCredit ? "+" : "-"}
            {tx.amount.toLocaleString("en-SA", {
              minimumFractionDigits:
                tx.currency === "BTC" || tx.currency === "ETH" ? 6 : 2,
              maximumFractionDigits:
                tx.currency === "BTC" || tx.currency === "ETH" ? 6 : 2,
            })}{" "}
            {tx.currency}
          </Text>
        </View>
        <View style={styles.txBottom}>
          <Text style={styles.txMeta}>
            {tx.bankName
              ? `${tx.bankName} • `
              : ""}
            {formatDate(tx.createdAt)}
          </Text>
          <View
            style={[
              styles.statusBadge,
              {
                backgroundColor:
                  tx.status === "completed"
                    ? "#E8F5EE"
                    : tx.status === "pending"
                    ? "#FEF9C3"
                    : "#FDECEA",
              },
            ]}
          >
            <Text
              style={[
                styles.statusText,
                {
                  color:
                    tx.status === "completed"
                      ? Colors.light.positive
                      : tx.status === "pending"
                      ? "#B45309"
                      : Colors.light.negative,
                },
              ]}
            >
              {t(
                tx.status.charAt(0).toUpperCase() + tx.status.slice(1),
                tx.status === "completed"
                  ? "مكتمل"
                  : tx.status === "pending"
                  ? "معلق"
                  : "فشل"
              )}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

export default function HistoryScreen() {
  const insets = useSafeAreaInsets();
  const { transactions, t } = useWallet();
  const [activeFilter, setActiveFilter] = useState<string>("all");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : 0;

  const filtered = useMemo(() => {
    if (activeFilter === "all") return transactions;
    return transactions.filter((tx) => tx.type === activeFilter || (activeFilter === "transfer_out" && tx.type === "transfer_in"));
  }, [transactions, activeFilter]);

  const grouped = useMemo(() => {
    const groups: { title: string; data: Transaction[] }[] = [];
    const map = new Map<string, Transaction[]>();
    filtered.forEach((tx) => {
      const date = new Date(tx.createdAt);
      const now = new Date();
      let key: string;
      const diffDays = Math.floor(
        (now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24)
      );
      if (diffDays === 0) key = "Today";
      else if (diffDays === 1) key = "Yesterday";
      else key = date.toLocaleDateString("en-SA", { month: "long", day: "numeric" });
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(tx);
    });
    map.forEach((data, title) => groups.push({ title, data }));
    return groups;
  }, [filtered]);

  const flatData = useMemo(() => {
    const items: (string | Transaction)[] = [];
    grouped.forEach((g) => {
      items.push(g.title);
      g.data.forEach((tx) => items.push(tx));
    });
    return items;
  }, [grouped]);

  return (
    <View
      style={[
        styles.container,
        { paddingTop: topPad, paddingBottom: bottomPad },
      ]}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>{t("Transaction History", "سجل المعاملات")}</Text>
        <Text style={styles.count}>
          {filtered.length} {t("transactions", "معاملة")}
        </Text>
      </View>

      {/* Filters */}
      <View style={styles.filtersContainer}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={FILTERS}
          keyExtractor={(item) => item.key}
          contentContainerStyle={styles.filters}
          renderItem={({ item }) => (
            <Pressable
              style={[
                styles.filterChip,
                activeFilter === item.key && styles.filterChipActive,
              ]}
              onPress={() => setActiveFilter(item.key)}
            >
              <Text
                style={[
                  styles.filterText,
                  activeFilter === item.key && styles.filterTextActive,
                ]}
              >
                {t(item.en, item.ar)}
              </Text>
            </Pressable>
          )}
        />
      </View>

      {/* Transactions */}
      {filtered.length === 0 ? (
        <View style={styles.emptyState}>
          <Feather name="inbox" size={50} color={Colors.light.border} />
          <Text style={styles.emptyTitle}>
            {t("No Transactions", "لا توجد معاملات")}
          </Text>
          <Text style={styles.emptyText}>
            {t("Your transaction history will appear here", "سيظهر سجل معاملاتك هنا")}
          </Text>
        </View>
      ) : (
        <FlatList
          data={flatData}
          keyExtractor={(item, idx) =>
            typeof item === "string" ? `group-${idx}` : item.id
          }
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => {
            if (typeof item === "string") {
              return <Text style={styles.groupHeader}>{item}</Text>;
            }
            return (
              <View style={styles.txCard}>
                <TransactionItem tx={item} />
              </View>
            );
          }}
        />
      )}
    </View>
  );
}

function getTransactionIcon(type: string) {
  switch (type) {
    case "deposit":
      return { bg: "#E8F5EE", element: <Feather name="arrow-down-circle" size={18} color="#1A7A4A" /> };
    case "transfer_in":
      return { bg: "#E8F5EE", element: <Feather name="arrow-down-left" size={18} color="#1A7A4A" /> };
    case "transfer_out":
      return { bg: "#FDECEA", element: <Feather name="arrow-up-right" size={18} color="#DC3545" /> };
    case "exchange":
      return { bg: "#F3E8FF", element: <Ionicons name="swap-horizontal" size={18} color="#9333EA" /> };
    case "crypto_transfer":
      return { bg: "#FEF3C7", element: <Feather name="send" size={18} color="#D97706" /> };
    default:
      return { bg: "#F3F4F6", element: <Feather name="activity" size={18} color="#6B7280" /> };
  }
}

function formatDate(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return "Yesterday";
  return date.toLocaleDateString("en-SA", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  count: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  filtersContainer: {
    marginBottom: 12,
  },
  filters: {
    paddingHorizontal: 20,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 1.5,
    borderColor: Colors.light.border,
  },
  filterChipActive: {
    backgroundColor: Colors.light.tint,
    borderColor: Colors.light.tint,
  },
  filterText: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_500Medium",
  },
  filterTextActive: {
    color: "#fff",
    fontFamily: "Inter_600SemiBold",
  },
  listContent: {
    paddingHorizontal: 20,
    paddingBottom: 120,
  },
  groupHeader: {
    fontSize: 13,
    fontWeight: "600",
    color: Colors.light.textMuted,
    fontFamily: "Inter_600SemiBold",
    marginTop: 16,
    marginBottom: 8,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  txCard: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 16,
    marginBottom: 8,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 1,
    shadowRadius: 4,
    elevation: 1,
  },
  txItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  txIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  txContent: {
    flex: 1,
  },
  txTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 8,
  },
  txDesc: {
    flex: 1,
    fontSize: 14,
    fontWeight: "500",
    color: Colors.light.text,
    fontFamily: "Inter_500Medium",
  },
  txAmount: {
    fontSize: 14,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
    flexShrink: 0,
  },
  txBottom: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 4,
  },
  txMeta: {
    fontSize: 12,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  emptyText: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    textAlign: "center",
    fontFamily: "Inter_400Regular",
  },
});
