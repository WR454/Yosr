import { Feather, Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  Alert,
  Dimensions,
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { CardItem, useWallet } from "@/context/WalletContext";

const { width } = Dimensions.get("window");
const CARD_WIDTH = width - 40;

function BankCard({ card, isSelected }: { card: CardItem; isSelected: boolean }) {
  const gradients: Record<string, [string, string]> = {
    "#1A7A4A": ["#1A7A4A", "#0D5533"],
    "#0F1E14": ["#1C2E22", "#0F1E14"],
    "#C9A84C": ["#C9A84C", "#A0822E"],
    "#1C1C1E": ["#2C2C2E", "#1C1C1E"],
    "#2563EB": ["#2563EB", "#1D4ED8"],
    "#9333EA": ["#9333EA", "#7E22CE"],
  };
  const gradient = gradients[card.color] || ["#1A7A4A", "#0D5533"];

  return (
    <LinearGradient
      colors={card.isFrozen ? ["#6B7280", "#374151"] : gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[styles.bankCard, isSelected && styles.selectedCard]}
    >
      <View style={styles.cardDecor1} />
      <View style={styles.cardDecor2} />
      {card.isFrozen && (
        <View style={styles.frozenOverlay}>
          <MaterialCommunityIcons name="snowflake" size={28} color="rgba(255,255,255,0.9)" />
          <Text style={styles.frozenText}>FROZEN</Text>
        </View>
      )}
      <View style={styles.cardTop}>
        <View style={styles.cardChipArea}>
          <View style={styles.chip} />
          {card.isDefault && (
            <View style={styles.defaultBadge}>
              <Text style={styles.defaultBadgeText}>DEFAULT</Text>
            </View>
          )}
        </View>
        <View style={styles.cardTypeTag}>
          <Text style={styles.cardTypeText}>{card.type.toUpperCase()}</Text>
        </View>
      </View>
      <Text style={styles.cardNumber}>
        •••• •••• •••• {card.lastFour}
      </Text>
      <View style={styles.cardBottom}>
        <View>
          <Text style={styles.cardLabel}>CARD HOLDER</Text>
          <Text style={styles.cardHolder} numberOfLines={1}>{card.holderName}</Text>
        </View>
        <View style={styles.cardExpiry}>
          <Text style={styles.cardLabel}>EXPIRES</Text>
          <Text style={styles.cardHolder}>
            {String(card.expiryMonth).padStart(2, "0")}/{card.expiryYear}
          </Text>
        </View>
        <View>
          <Text
            style={[
              styles.brandLogo,
              {
                color: card.brand === "visa" ? "#fff" : card.brand === "mastercard" ? "#FF5F00" : "#00B050",
              },
            ]}
          >
            {card.brand === "visa"
              ? "VISA"
              : card.brand === "mastercard"
              ? "MC"
              : "mada"}
          </Text>
        </View>
      </View>
    </LinearGradient>
  );
}

export default function CardsScreen() {
  const insets = useSafeAreaInsets();
  const { cards, removeCard, setDefaultCard, freezeCard, t } = useWallet();
  const [selectedIndex, setSelectedIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);

  const selectedCard = cards[selectedIndex] ?? cards[0];

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const handleRemoveCard = () => {
    if (!selectedCard) return;
    Alert.alert(
      t("Remove Card", "إزالة البطاقة"),
      t(
        `Remove card ending in ${selectedCard.lastFour}?`,
        `هل تريد إزالة البطاقة المنتهية بـ ${selectedCard.lastFour}؟`
      ),
      [
        { text: t("Cancel", "إلغاء"), style: "cancel" },
        {
          text: t("Remove", "إزالة"),
          style: "destructive",
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            removeCard(selectedCard.id);
            const newIndex = Math.max(0, selectedIndex - 1);
            setSelectedIndex(newIndex);
          },
        },
      ]
    );
  };

  const handleSetDefault = () => {
    if (!selectedCard || selectedCard.isDefault) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setDefaultCard(selectedCard.id);
  };

  const handleFreezeToggle = () => {
    if (!selectedCard) return;
    const willFreeze = !selectedCard.isFrozen;
    Alert.alert(
      willFreeze ? t("Freeze Card", "تجميد البطاقة") : t("Unfreeze Card", "إلغاء تجميد البطاقة"),
      willFreeze
        ? t(
            `Freeze card ending in ${selectedCard.lastFour}? All transactions will be blocked.`,
            `تجميد البطاقة المنتهية بـ ${selectedCard.lastFour}؟ سيتم حظر جميع المعاملات.`
          )
        : t(
            `Unfreeze card ending in ${selectedCard.lastFour}?`,
            `إلغاء تجميد البطاقة المنتهية بـ ${selectedCard.lastFour}؟`
          ),
      [
        { text: t("Cancel", "إلغاء"), style: "cancel" },
        {
          text: willFreeze ? t("Freeze", "تجميد") : t("Unfreeze", "إلغاء التجميد"),
          style: willFreeze ? "destructive" : "default",
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            freezeCard(selectedCard.id, willFreeze);
          },
        },
      ]
    );
  };

  const handleOpenDetail = () => {
    if (!selectedCard) return;
    router.push({ pathname: "/card-detail", params: { cardId: selectedCard.id } });
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>{t("My Cards", "بطاقاتي")}</Text>
        <Pressable
          style={styles.addBtn}
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            router.push("/add-card");
          }}
        >
          <Feather name="plus" size={20} color={Colors.light.tint} />
          <Text style={styles.addBtnText}>{t("Add Card", "إضافة بطاقة")}</Text>
        </Pressable>
      </View>

      {cards.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="card-outline" size={60} color={Colors.light.border} />
          <Text style={styles.emptyTitle}>{t("No Cards", "لا توجد بطاقات")}</Text>
          <Text style={styles.emptyText}>
            {t("Add your first card to get started", "أضف بطاقتك الأولى للبدء")}
          </Text>
          <Pressable
            style={styles.emptyBtn}
            onPress={() => router.push("/add-card")}
          >
            <Text style={styles.emptyBtnText}>{t("Add Card", "إضافة بطاقة")}</Text>
          </Pressable>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 40 }}
        >
          {/* Cards Carousel */}
          <FlatList
            ref={flatListRef}
            data={cards}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            snapToInterval={CARD_WIDTH + 16}
            decelerationRate="fast"
            contentContainerStyle={{ paddingHorizontal: 20, gap: 16 }}
            onMomentumScrollEnd={(e) => {
              const index = Math.round(
                e.nativeEvent.contentOffset.x / (CARD_WIDTH + 16)
              );
              setSelectedIndex(index);
            }}
            renderItem={({ item, index }) => (
              <BankCard card={item} isSelected={index === selectedIndex} />
            )}
            keyExtractor={(item) => item.id}
            style={styles.carousel}
            scrollEnabled
            nestedScrollEnabled
          />

          {/* Dots */}
          <View style={styles.dots}>
            {cards.map((_, i) => (
              <View
                key={i}
                style={[styles.dot, i === selectedIndex && styles.dotActive]}
              />
            ))}
          </View>

          {/* Card Actions */}
          {selectedCard && (
            <View style={styles.cardActions}>
              <Text style={styles.cardActionsTitle}>
                {t("Card Actions", "إجراءات البطاقة")}
              </Text>
              <View style={styles.actionGrid}>
                <Pressable
                  style={[
                    styles.actionBtn,
                    selectedCard.isDefault && styles.actionBtnActive,
                  ]}
                  onPress={handleSetDefault}
                >
                  <View style={[styles.actionIcon, { backgroundColor: Colors.light.tint + "15" }]}>
                    <Ionicons
                      name="star"
                      size={20}
                      color={selectedCard.isDefault ? Colors.light.tint : Colors.light.textMuted}
                    />
                  </View>
                  <Text style={styles.actionLabel}>
                    {selectedCard.isDefault
                      ? t("Default", "افتراضي")
                      : t("Set Default", "تعيين افتراضي")}
                  </Text>
                </Pressable>

                <Pressable style={styles.actionBtn} onPress={handleOpenDetail}>
                  <View style={[styles.actionIcon, { backgroundColor: "#2563EB15" }]}>
                    <Feather name="eye" size={20} color="#2563EB" />
                  </View>
                  <Text style={styles.actionLabel}>{t("Details", "التفاصيل")}</Text>
                </Pressable>

                <Pressable style={styles.actionBtn} onPress={handleFreezeToggle}>
                  <View
                    style={[
                      styles.actionIcon,
                      {
                        backgroundColor: selectedCard.isFrozen
                          ? "#60A5FA20"
                          : "#9333EA15",
                      },
                    ]}
                  >
                    <MaterialCommunityIcons
                      name={selectedCard.isFrozen ? "snowflake-off" : "snowflake"}
                      size={20}
                      color={selectedCard.isFrozen ? "#60A5FA" : "#9333EA"}
                    />
                  </View>
                  <Text style={styles.actionLabel}>
                    {selectedCard.isFrozen
                      ? t("Unfreeze", "إلغاء التجميد")
                      : t("Freeze", "تجميد")}
                  </Text>
                </Pressable>

                <Pressable style={styles.actionBtn} onPress={handleRemoveCard}>
                  <View style={[styles.actionIcon, { backgroundColor: Colors.light.error + "15" }]}>
                    <Feather name="trash-2" size={20} color={Colors.light.error} />
                  </View>
                  <Text style={[styles.actionLabel, { color: Colors.light.error }]}>
                    {t("Remove", "إزالة")}
                  </Text>
                </Pressable>
              </View>

              {/* Card Stats */}
              <View style={styles.cardStats}>
                <View style={styles.statRow}>
                  <Text style={styles.statLabel}>{t("Card Type", "نوع البطاقة")}</Text>
                  <Text style={styles.statValue}>
                    {selectedCard.type === "virtual"
                      ? t("Virtual", "افتراضية")
                      : t("Physical", "مادية")}
                  </Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statRow}>
                  <Text style={styles.statLabel}>{t("Currency", "العملة")}</Text>
                  <Text style={styles.statValue}>{selectedCard.currency}</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statRow}>
                  <Text style={styles.statLabel}>{t("Network", "الشبكة")}</Text>
                  <Text style={styles.statValue}>
                    {selectedCard.brand.toUpperCase()}
                  </Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statRow}>
                  <Text style={styles.statLabel}>{t("Status", "الحالة")}</Text>
                  <View
                    style={[
                      styles.statusBadge,
                      { backgroundColor: selectedCard.isFrozen ? "#EFF6FF" : "#E8F5EE" },
                    ]}
                  >
                    <View
                      style={[
                        styles.statusDot,
                        { backgroundColor: selectedCard.isFrozen ? "#60A5FA" : Colors.light.positive },
                      ]}
                    />
                    <Text
                      style={[
                        styles.statusText,
                        { color: selectedCard.isFrozen ? "#60A5FA" : Colors.light.positive },
                      ]}
                    >
                      {selectedCard.isFrozen ? t("Frozen", "مجمدة") : t("Active", "نشطة")}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  addBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: Colors.light.tint + "15",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addBtnText: {
    fontSize: 13,
    fontWeight: "600",
    color: Colors.light.tint,
    fontFamily: "Inter_600SemiBold",
  },
  carousel: {
    flexGrow: 0,
  },
  bankCard: {
    width: CARD_WIDTH,
    height: 210,
    borderRadius: 24,
    padding: 22,
    justifyContent: "space-between",
    overflow: "hidden",
    position: "relative",
  },
  selectedCard: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 10,
  },
  frozenOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  frozenText: {
    fontSize: 11,
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_700Bold",
    letterSpacing: 3,
  },
  cardDecor1: {
    position: "absolute",
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: "rgba(255,255,255,0.06)",
    top: -60,
    right: -40,
  },
  cardDecor2: {
    position: "absolute",
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "rgba(255,255,255,0.04)",
    bottom: -50,
    left: -20,
  },
  cardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  cardChipArea: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  chip: {
    width: 36,
    height: 28,
    borderRadius: 6,
    backgroundColor: "rgba(255,215,0,0.6)",
  },
  defaultBadge: {
    backgroundColor: Colors.light.gold,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  defaultBadgeText: {
    fontSize: 9,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  cardTypeTag: {
    backgroundColor: "rgba(255,255,255,0.15)",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  cardTypeText: {
    fontSize: 9,
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.5,
  },
  cardNumber: {
    fontSize: 17,
    color: "rgba(255,255,255,0.9)",
    fontFamily: "Inter_500Medium",
    letterSpacing: 3,
  },
  cardBottom: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
  },
  cardLabel: {
    fontSize: 9,
    color: "rgba(255,255,255,0.5)",
    fontFamily: "Inter_400Regular",
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  cardHolder: {
    fontSize: 12,
    color: "#fff",
    fontFamily: "Inter_600SemiBold",
    maxWidth: 130,
  },
  cardExpiry: {},
  brandLogo: {
    fontSize: 16,
    fontWeight: "800",
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  dots: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 6,
    marginTop: 16,
    marginBottom: 8,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.light.border,
  },
  dotActive: {
    width: 20,
    backgroundColor: Colors.light.tint,
  },
  cardActions: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  cardActionsTitle: {
    fontSize: 15,
    fontWeight: "600",
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 14,
  },
  actionGrid: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 20,
  },
  actionBtn: {
    flex: 1,
    alignItems: "center",
    gap: 6,
  },
  actionBtnActive: {},
  actionIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  actionLabel: {
    fontSize: 11,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_500Medium",
    textAlign: "center",
  },
  cardStats: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 2,
  },
  statRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 6,
  },
  statDivider: {
    height: 1,
    backgroundColor: Colors.light.borderLight,
  },
  statLabel: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
  },
  statValue: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.light.text,
    fontFamily: "Inter_600SemiBold",
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
  },
  statusText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 40,
    gap: 12,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  emptyText: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    textAlign: "center",
    fontFamily: "Inter_400Regular",
  },
  emptyBtn: {
    backgroundColor: Colors.light.tint,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 14,
    marginTop: 8,
  },
  emptyBtnText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#fff",
    fontFamily: "Inter_600SemiBold",
  },
});
