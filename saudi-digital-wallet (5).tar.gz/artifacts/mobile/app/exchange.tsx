import { router } from "expo-router";
import React from "react";
import { View, StyleSheet } from "react-native";

// This route redirects to the exchange tab
export default function ExchangeModal() {
  React.useEffect(() => {
    router.replace("/(tabs)/exchange");
  }, []);
  return <View style={{ flex: 1 }} />;
}
