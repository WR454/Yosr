import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { useWallet } from "@/context/WalletContext";

type CryptoAsset = {
  symbol: string;
  name: string;
  nameAr: string;
  color: string;
  icon: string;
  getBalance: (w: any) => number;
  rate: (r: any) => number;
};

export default function CryptoTransferScreen() {
  const insets = useSafeAreaInsets();
  const { wallet, exchangeRates, transferCrypto, t } = useWallet();
  const [selectedCrypto, setSelectedCrypto] = useState("BTC");
  const [amount, setAmount] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const CRYPTOS: CryptoAsset[] = [
    {
      symbol: "BTC",
      name: "Bitcoin",
      nameAr: "بيتكوين",
      color: "#F7931A",
      icon: "₿",
      getBalance: (w) => w.btcBalance,
      rate: (r) => r.btcSar,
    },
    {
      symbol: "ETH",
      name: "Ethereum",
      nameAr: "إيثيريوم",
      color: "#627EEA",
      icon: "Ξ",
      getBalance: (w) => w.ethBalance,
      rate: (r) => r.ethSar,
    },
    {
      symbol: "USDT",
      name: "Tether",
      nameAr: "تيثر",
      color: "#26A17B",
      icon: "₮",
      getBalance: (w) => w.usdtBalance,
      rate: (r) => r.usdtSar,
    },
  ];

  const currentCrypto = CRYPTOS.find((c) => c.symbol === selectedCrypto)!;
  const currentBalance = currentCrypto.getBalance(wallet);
  const parsedAmount = parseFloat(amount) || 0;
  const sarEquivalent = parsedAmount * currentCrypto.rate(exchangeRates);

  const handleTransfer = () => {
    if (!address.trim()) {
      Alert.alert(t("Missing Address", "العنوان مفقود"), t("Please enter a wallet address", "أدخل عنوان المحفظة"));
      return;
    }
    if (!parsedAmount || parsedAmount <= 0) {
      Alert.alert(t("Invalid Amount", "مبلغ غير صالح"), t("Enter a valid amount", "أدخل مبلغاً صحيحاً"));
      return;
    }
    if (parsedAmount > currentBalance) {
      Alert.alert(t("Insufficient Balance", "رصيد غير كافٍ"), t(`You don't have enough ${selectedCrypto}`, `رصيد ${selectedCrypto} غير كافٍ`));
      return;
    }

    Alert.alert(
      t("Confirm Transfer", "تأكيد التحويل"),
      t(
        `Send ${parsedAmount} ${selectedCrypto} to ${address.substring(0, 12)}...?`,
        `إرسال ${parsedAmount} ${selectedCrypto} إلى ${address.substring(0, 12)}...؟`
      ),
      [
        { text: t("Cancel", "إلغاء"), style: "cancel" },
        {
          text: t("Send", "إرسال"),
          style: "destructive",
          onPress: () => {
            const success = transferCrypto(selectedCrypto, parsedAmount, address);
            if (success) {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              Alert.alert(
                t("Transfer Sent!", "تم الإرسال!"),
                t(`${parsedAmount} ${selectedCrypto} has been sent.`, `تم إرسال ${parsedAmount} ${selectedCrypto}.`),
                [{ text: "OK", onPress: () => router.back() }]
              );
            } else {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
              Alert.alert(t("Transfer Failed", "فشل التحويل"), t("Please try again", "حاول مرة أخرى"));
            }
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Feather name="x" size={22} color={Colors.light.text} />
        </Pressable>
        <Text style={styles.title}>{t("Send Crypto", "إرسال كريبتو")}</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 20 }]}
        keyboardShouldPersistTaps="handled"
      >
        {/* Select Crypto */}
        <Text style={styles.fieldLabel}>{t("Select Asset", "اختر الأصل")}</Text>
        <View style={styles.cryptoRow}>
          {CRYPTOS.map((crypto) => (
            <Pressable
              key={crypto.symbol}
              style={[
                styles.cryptoBtn,
                selectedCrypto === crypto.symbol && {
                  borderColor: crypto.color,
                  backgroundColor: crypto.color + "12",
                },
              ]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedCrypto(crypto.symbol);
                setAmount("");
              }}
            >
              <Text style={[styles.cryptoIcon, { color: crypto.color }]}>{crypto.icon}</Text>
              <Text
                style={[
                  styles.cryptoLabel,
                  selectedCrypto === crypto.symbol && { color: crypto.color, fontFamily: "Inter_700Bold" },
                ]}
              >
                {crypto.symbol}
              </Text>
              <Text style={styles.cryptoBalance}>
                {crypto.getBalance(wallet).toFixed(crypto.symbol === "USDT" ? 2 : 6)}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Balance Info */}
        <View style={[styles.balanceInfo, { borderLeftColor: currentCrypto.color }]}>
          <MaterialCommunityIcons name="bitcoin" size={16} color={currentCrypto.color} />
          <Text style={styles.balanceInfoText}>
            {t("Available:", "المتاح:")}{" "}
            <Text style={[styles.balanceInfoAmount, { color: currentCrypto.color }]}>
              {currentBalance.toFixed(selectedCrypto === "USDT" ? 2 : 6)} {selectedCrypto}
            </Text>
            {" "}≈{" "}
            {(currentBalance * currentCrypto.rate(exchangeRates)).toLocaleString("en-SA", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} SAR
          </Text>
        </View>

        {/* Amount */}
        <Text style={styles.fieldLabel}>{t("Amount", "المبلغ")}</Text>
        <View style={styles.amountContainer}>
          <TextInput
            style={styles.amountInput}
            placeholder="0.000000"
            placeholderTextColor={Colors.light.textMuted}
            keyboardType="decimal-pad"
            value={amount}
            onChangeText={setAmount}
          />
          <Text style={[styles.amountCurrency, { color: currentCrypto.color }]}>
            {selectedCrypto}
          </Text>
        </View>
        {parsedAmount > 0 && (
          <Text style={styles.sarEquiv}>
            ≈ {sarEquivalent.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR
          </Text>
        )}

        {/* Percentage Quick Select */}
        <View style={styles.percentRow}>
          {[25, 50, 75, 100].map((pct) => (
            <Pressable
              key={pct}
              style={styles.percentChip}
              onPress={() => {
                Haptics.selectionAsync();
                const val = (currentBalance * pct) / 100;
                setAmount(val.toFixed(selectedCrypto === "USDT" ? 2 : 6));
              }}
            >
              <Text style={styles.percentText}>{pct}%</Text>
            </Pressable>
          ))}
        </View>

        {/* Wallet Address */}
        <Text style={styles.fieldLabel}>{t("Recipient Address", "عنوان المستفيد")}</Text>
        <TextInput
          style={[styles.input, styles.addressInput]}
          placeholder={t("Enter wallet address", "أدخل عنوان المحفظة")}
          placeholderTextColor={Colors.light.textMuted}
          value={address}
          onChangeText={setAddress}
          autoCapitalize="none"
          autoCorrect={false}
          multiline
        />

        {/* Note */}
        <Text style={styles.fieldLabel}>{t("Note (Optional)", "ملاحظة (اختياري)")}</Text>
        <TextInput
          style={styles.input}
          placeholder={t("Add a note...", "أضف ملاحظة...")}
          placeholderTextColor={Colors.light.textMuted}
          value={note}
          onChangeText={setNote}
        />

        {/* Warning */}
        <View style={styles.warning}>
          <Feather name="alert-triangle" size={14} color="#D97706" />
          <Text style={styles.warningText}>
            {t(
              "Crypto transfers are irreversible. Double-check the address before sending.",
              "تحويلات الكريبتو لا يمكن التراجع عنها. تحقق من العنوان قبل الإرسال."
            )}
          </Text>
        </View>

        {/* Send Button */}
        <Pressable
          style={({ pressed }) => [styles.sendBtn, { opacity: pressed ? 0.85 : 1 }]}
          onPress={handleTransfer}
        >
          <LinearGradient
            colors={[currentCrypto.color, currentCrypto.color + "CC"]}
            style={styles.sendBtnGradient}
          >
            <Feather name="send" size={20} color="#fff" />
            <Text style={styles.sendBtnText}>
              {t(`Send ${selectedCrypto}`, `إرسال ${selectedCrypto}`)}
            </Text>
          </LinearGradient>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.light.background },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.light.backgroundTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
  },
  content: { paddingHorizontal: 20, paddingTop: 4 },
  fieldLabel: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 10,
    marginTop: 12,
  },
  cryptoRow: {
    flexDirection: "row",
    gap: 12,
  },
  cryptoBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 14,
    borderRadius: 16,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 2,
    borderColor: Colors.light.border,
    gap: 4,
  },
  cryptoIcon: {
    fontSize: 20,
    fontWeight: "700",
  },
  cryptoLabel: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    color: Colors.light.text,
  },
  cryptoBalance: {
    fontSize: 10,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
  },
  balanceInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 12,
    padding: 12,
    borderLeftWidth: 3,
    marginTop: 8,
  },
  balanceInfoText: {
    fontSize: 13,
    color: Colors.light.textSecondary,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  balanceInfoAmount: {
    fontFamily: "Inter_700Bold",
  },
  amountContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderWidth: 2,
    borderColor: Colors.light.border,
    gap: 10,
  },
  amountInput: {
    flex: 1,
    fontSize: 28,
    fontWeight: "700",
    color: Colors.light.text,
    fontFamily: "Inter_700Bold",
    padding: 0,
  },
  amountCurrency: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  sarEquiv: {
    fontSize: 12,
    color: Colors.light.textMuted,
    fontFamily: "Inter_400Regular",
    marginTop: 6,
  },
  percentRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 10,
  },
  percentChip: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 1.5,
    borderColor: Colors.light.border,
  },
  percentText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    color: Colors.light.textSecondary,
  },
  input: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 14,
    color: Colors.light.text,
    fontFamily: "Inter_400Regular",
    borderWidth: 1.5,
    borderColor: Colors.light.border,
  },
  addressInput: {
    minHeight: 70,
    textAlignVertical: "top",
  },
  warning: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    backgroundColor: "#FEF3C7",
    borderRadius: 12,
    padding: 12,
    marginTop: 12,
  },
  warningText: {
    flex: 1,
    fontSize: 12,
    color: "#92400E",
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
  },
  sendBtn: {
    borderRadius: 16,
    overflow: "hidden",
    marginTop: 20,
  },
  sendBtnGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 18,
  },
  sendBtnText: {
    fontSize: 17,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
});
