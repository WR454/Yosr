const primary = "#1A7A4A";
const primaryDark = "#145E38";
const primaryLight = "#2EAD6B";
const gold = "#C9A84C";
const goldLight = "#F0C96A";

export default {
  light: {
    text: "#0F1E14",
    textSecondary: "#4A6355",
    textMuted: "#8BA396",
    background: "#F5F8F6",
    backgroundSecondary: "#FFFFFF",
    backgroundTertiary: "#EBF2EE",
    tint: primary,
    tintDark: primaryDark,
    tintLight: primaryLight,
    gold: gold,
    goldLight: goldLight,
    tabIconDefault: "#8BA396",
    tabIconSelected: primary,
    cardBg1: "#1A7A4A",
    cardBg2: "#0F4D2E",
    cardBg3: "#2D2D2D",
    border: "#D6E4DC",
    borderLight: "#EBF2EE",
    error: "#DC3545",
    success: "#1A7A4A",
    warning: "#F5A623",
    positive: "#1A7A4A",
    negative: "#DC3545",
    shadow: "rgba(26, 122, 74, 0.15)",
    overlay: "rgba(0, 0, 0, 0.5)",
  },
};
