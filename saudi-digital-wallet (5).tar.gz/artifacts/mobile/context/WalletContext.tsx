import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

export type Language = "en" | "ar";

export const ACCOUNT_HOLDER = "Ali Jaber Amer Al-Shehri";
export const ACCOUNT_HOLDER_AR = "علي جابر عامر الشهري";
export const ACCOUNT_IBAN = "SA21 4000 0001 2345 6789 1234";
export const ACCOUNT_NUMBER = "4000001234567891";
export const PRIMARY_BANK = "Arab National Bank";
export const PRIMARY_BANK_AR = "البنك العربي الوطني";
export const PRIMARY_BANK_SHORT = "ANB";
export const APP_BRAND = "11";

export interface WalletBalance {
  sarBalance: number;
  btcBalance: number;
  ethBalance: number;
  usdtBalance: number;
  totalSarValue: number;
}

export interface CardItem {
  id: string;
  type: "virtual" | "physical";
  brand: "visa" | "mastercard" | "mada";
  lastFour: string;
  holderName: string;
  expiryMonth: number;
  expiryYear: number;
  isDefault: boolean;
  isFrozen: boolean;
  color: string;
  currency: string;
}

export interface Transaction {
  id: string;
  type:
    | "deposit"
    | "withdrawal"
    | "transfer_out"
    | "transfer_in"
    | "exchange"
    | "crypto_transfer";
  amount: number;
  currency: string;
  description: string;
  descriptionAr: string;
  status: "pending" | "completed" | "failed";
  createdAt: string;
  recipientName?: string;
  bankName?: string;
}

export interface ExchangeRates {
  btcSar: number;
  ethSar: number;
  usdtSar: number;
  usdSar: number;
  eurSar: number;
  updatedAt: string;
}

interface WalletContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (en: string, ar: string) => string;
  isRTL: boolean;
  wallet: WalletBalance;
  cards: CardItem[];
  transactions: Transaction[];
  exchangeRates: ExchangeRates;
  refreshWallet: () => void;
  addCard: (card: Omit<CardItem, "id">) => void;
  removeCard: (id: string) => void;
  setDefaultCard: (id: string) => void;
  freezeCard: (id: string, frozen: boolean) => void;
  addTransaction: (tx: Omit<Transaction, "id" | "createdAt">) => void;
  depositFunds: (amount: number, method: string) => void;
  transferLocal: (
    amount: number,
    iban: string,
    name: string,
    bank: string,
    note?: string
  ) => boolean;
  exchangeCurrency: (
    from: string,
    to: string,
    amount: number
  ) => { success: boolean; receivedAmount: number };
  transferCrypto: (
    currency: string,
    amount: number,
    address: string
  ) => boolean;
}

const WalletContext = createContext<WalletContextType | null>(null);

const INITIAL_WALLET: WalletBalance = {
  sarBalance: 12500.0,
  btcBalance: 0.0145,
  ethBalance: 0.5,
  usdtBalance: 200.0,
  totalSarValue: 16850.0,
};

const INITIAL_CARDS: CardItem[] = [
  {
    id: "card-1",
    type: "physical",
    brand: "mada",
    lastFour: "4291",
    holderName: ACCOUNT_HOLDER,
    expiryMonth: 12,
    expiryYear: 27,
    isDefault: true,
    isFrozen: false,
    color: "#1A7A4A",
    currency: "SAR",
  },
  {
    id: "card-2",
    type: "virtual",
    brand: "visa",
    lastFour: "8854",
    holderName: ACCOUNT_HOLDER,
    expiryMonth: 9,
    expiryYear: 26,
    isDefault: false,
    isFrozen: false,
    color: "#0F1E14",
    currency: "SAR",
  },
  {
    id: "card-3",
    type: "virtual",
    brand: "mastercard",
    lastFour: "3317",
    holderName: ACCOUNT_HOLDER,
    expiryMonth: 3,
    expiryYear: 28,
    isDefault: false,
    isFrozen: false,
    color: "#C9A84C",
    currency: "USD",
  },
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: "tx-1",
    type: "transfer_in",
    amount: 2500,
    currency: "SAR",
    description: "Received from Mohammed Al-Otaibi",
    descriptionAr: "تحويل من محمد العتيبي",
    status: "completed",
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    recipientName: "Mohammed Al-Otaibi",
    bankName: "Arab National Bank",
  },
  {
    id: "tx-2",
    type: "exchange",
    amount: 1000,
    currency: "SAR",
    description: "Exchanged SAR to USDT",
    descriptionAr: "تحويل ريال إلى يو إس دي تي",
    status: "completed",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
  },
  {
    id: "tx-3",
    type: "transfer_out",
    amount: 750,
    currency: "SAR",
    description: "Transfer to Khalid Al-Ghamdi",
    descriptionAr: "تحويل إلى خالد الغامدي",
    status: "completed",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    recipientName: "Khalid Al-Ghamdi",
    bankName: "SNB",
  },
  {
    id: "tx-4",
    type: "deposit",
    amount: 5000,
    currency: "SAR",
    description: "Deposit via Bank Transfer",
    descriptionAr: "إيداع عبر تحويل بنكي",
    status: "completed",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
  },
  {
    id: "tx-5",
    type: "crypto_transfer",
    amount: 0.005,
    currency: "BTC",
    description: "BTC Transfer to external wallet",
    descriptionAr: "تحويل بيتكوين لمحفظة خارجية",
    status: "completed",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
  },
  {
    id: "tx-6",
    type: "transfer_out",
    amount: 1200,
    currency: "SAR",
    description: "Transfer to Fatima Al-Zahrani",
    descriptionAr: "تحويل إلى فاطمة الزهراني",
    status: "completed",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
    recipientName: "Fatima Al-Zahrani",
    bankName: "Riyad Bank",
  },
];

const INITIAL_RATES: ExchangeRates = {
  btcSar: 149800,
  ethSar: 8250,
  usdtSar: 3.75,
  usdSar: 3.75,
  eurSar: 4.12,
  updatedAt: new Date().toISOString(),
};

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en");
  const [wallet, setWallet] = useState<WalletBalance>(INITIAL_WALLET);
  const [cards, setCards] = useState<CardItem[]>(INITIAL_CARDS);
  const [transactions, setTransactions] =
    useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [exchangeRates] = useState<ExchangeRates>(INITIAL_RATES);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [storedLang, storedWallet, storedCards, storedTxs] =
        await Promise.all([
          AsyncStorage.getItem("language"),
          AsyncStorage.getItem("wallet"),
          AsyncStorage.getItem("cards"),
          AsyncStorage.getItem("transactions"),
        ]);
      if (storedLang) setLanguageState(storedLang as Language);
      if (storedWallet) setWallet(JSON.parse(storedWallet));
      if (storedCards) {
        const parsed: CardItem[] = JSON.parse(storedCards);
        const migrated = parsed.map((c) => ({
          ...c,
          isFrozen: c.isFrozen ?? false,
        }));
        setCards(migrated);
      }
      if (storedTxs) setTransactions(JSON.parse(storedTxs));
    } catch (_) {}
  };

  const saveWallet = async (w: WalletBalance) => {
    await AsyncStorage.setItem("wallet", JSON.stringify(w));
    setWallet(w);
  };

  const saveCards = async (c: CardItem[]) => {
    await AsyncStorage.setItem("cards", JSON.stringify(c));
    setCards(c);
  };

  const saveTransactions = async (txs: Transaction[]) => {
    await AsyncStorage.setItem("transactions", JSON.stringify(txs));
    setTransactions(txs);
  };

  const setLanguage = useCallback(async (lang: Language) => {
    await AsyncStorage.setItem("language", lang);
    setLanguageState(lang);
  }, []);

  const t = useCallback(
    (en: string, ar: string) => {
      return language === "ar" ? ar : en;
    },
    [language]
  );

  const isRTL = language === "ar";

  const refreshWallet = useCallback(() => {
    loadData();
  }, []);

  const addCard = useCallback(
    (card: Omit<CardItem, "id">) => {
      const newCard: CardItem = {
        ...card,
        id: `card-${Date.now()}`,
        isFrozen: false,
      };
      const updated = [...cards, newCard];
      saveCards(updated);
    },
    [cards]
  );

  const removeCard = useCallback(
    (id: string) => {
      const updated = cards.filter((c) => c.id !== id);
      saveCards(updated);
    },
    [cards]
  );

  const setDefaultCard = useCallback(
    (id: string) => {
      const updated = cards.map((c) => ({ ...c, isDefault: c.id === id }));
      saveCards(updated);
    },
    [cards]
  );

  const freezeCard = useCallback(
    (id: string, frozen: boolean) => {
      const updated = cards.map((c) =>
        c.id === id ? { ...c, isFrozen: frozen } : c
      );
      saveCards(updated);
    },
    [cards]
  );

  const addTransaction = useCallback(
    (tx: Omit<Transaction, "id" | "createdAt">) => {
      const newTx: Transaction = {
        ...tx,
        id: `tx-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      const updated = [newTx, ...transactions];
      saveTransactions(updated);
    },
    [transactions]
  );

  const depositFunds = useCallback(
    (amount: number, method: string) => {
      const methodLabels: Record<string, { en: string; ar: string }> = {
        bank_transfer: { en: "Bank Transfer", ar: "تحويل بنكي" },
        card: { en: "Card Payment", ar: "دفع بالبطاقة" },
        stcpay: { en: "STC Pay", ar: "STC Pay" },
        apple_pay: { en: "Apple Pay", ar: "Apple Pay" },
      };
      const label = methodLabels[method] || { en: "Deposit", ar: "إيداع" };
      addTransaction({
        type: "deposit",
        amount,
        currency: "SAR",
        description: `Deposit via ${label.en}`,
        descriptionAr: `إيداع عبر ${label.ar}`,
        status: "completed",
      });
      const newWallet = {
        ...wallet,
        sarBalance: wallet.sarBalance + amount,
        totalSarValue: wallet.totalSarValue + amount,
      };
      saveWallet(newWallet);
    },
    [wallet, addTransaction]
  );

  const transferLocal = useCallback(
    (
      amount: number,
      iban: string,
      name: string,
      bank: string,
      note?: string
    ): boolean => {
      if (wallet.sarBalance < amount) return false;
      addTransaction({
        type: "transfer_out",
        amount,
        currency: "SAR",
        description: `Transfer to ${name}`,
        descriptionAr: `تحويل إلى ${name}`,
        status: "completed",
        recipientName: name,
        bankName: bank,
      });
      saveWallet({
        ...wallet,
        sarBalance: wallet.sarBalance - amount,
        totalSarValue: wallet.totalSarValue - amount,
      });
      return true;
    },
    [wallet, addTransaction]
  );

  const exchangeCurrency = useCallback(
    (
      from: string,
      to: string,
      amount: number
    ): { success: boolean; receivedAmount: number } => {
      let receivedAmount = 0;
      const newWallet = { ...wallet };

      if (from === "SAR") {
        if (wallet.sarBalance < amount) return { success: false, receivedAmount: 0 };
        if (to === "BTC") {
          receivedAmount = amount / exchangeRates.btcSar;
          newWallet.btcBalance = wallet.btcBalance + receivedAmount;
        } else if (to === "ETH") {
          receivedAmount = amount / exchangeRates.ethSar;
          newWallet.ethBalance = wallet.ethBalance + receivedAmount;
        } else if (to === "USDT") {
          receivedAmount = amount / exchangeRates.usdtSar;
          newWallet.usdtBalance = wallet.usdtBalance + receivedAmount;
        } else {
          return { success: false, receivedAmount: 0 };
        }
        newWallet.sarBalance = wallet.sarBalance - amount;
      } else if (to === "SAR") {
        if (from === "BTC") {
          if (wallet.btcBalance < amount) return { success: false, receivedAmount: 0 };
          receivedAmount = amount * exchangeRates.btcSar;
          newWallet.btcBalance = wallet.btcBalance - amount;
        } else if (from === "ETH") {
          if (wallet.ethBalance < amount) return { success: false, receivedAmount: 0 };
          receivedAmount = amount * exchangeRates.ethSar;
          newWallet.ethBalance = wallet.ethBalance - amount;
        } else if (from === "USDT") {
          if (wallet.usdtBalance < amount) return { success: false, receivedAmount: 0 };
          receivedAmount = amount * exchangeRates.usdtSar;
          newWallet.usdtBalance = wallet.usdtBalance - amount;
        } else {
          return { success: false, receivedAmount: 0 };
        }
        newWallet.sarBalance = wallet.sarBalance + receivedAmount;
      } else {
        return { success: false, receivedAmount: 0 };
      }

      newWallet.totalSarValue =
        newWallet.sarBalance +
        newWallet.btcBalance * exchangeRates.btcSar +
        newWallet.ethBalance * exchangeRates.ethSar +
        newWallet.usdtBalance * exchangeRates.usdtSar;

      saveWallet(newWallet);
      addTransaction({
        type: "exchange",
        amount,
        currency: from,
        description: `Exchanged ${amount} ${from} to ${to}`,
        descriptionAr: `تحويل ${amount} ${from} إلى ${to}`,
        status: "completed",
      });
      return { success: true, receivedAmount };
    },
    [wallet, exchangeRates, addTransaction]
  );

  const transferCrypto = useCallback(
    (currency: string, amount: number, address: string): boolean => {
      const newWallet = { ...wallet };
      if (currency === "BTC") {
        if (wallet.btcBalance < amount) return false;
        newWallet.btcBalance = wallet.btcBalance - amount;
        newWallet.totalSarValue =
          wallet.totalSarValue - amount * exchangeRates.btcSar;
      } else if (currency === "ETH") {
        if (wallet.ethBalance < amount) return false;
        newWallet.ethBalance = wallet.ethBalance - amount;
        newWallet.totalSarValue =
          wallet.totalSarValue - amount * exchangeRates.ethSar;
      } else if (currency === "USDT") {
        if (wallet.usdtBalance < amount) return false;
        newWallet.usdtBalance = wallet.usdtBalance - amount;
        newWallet.totalSarValue =
          wallet.totalSarValue - amount * exchangeRates.usdtSar;
      } else {
        return false;
      }
      saveWallet(newWallet);
      addTransaction({
        type: "crypto_transfer",
        amount,
        currency,
        description: `${currency} Transfer to ${address.substring(0, 8)}...`,
        descriptionAr: `تحويل ${currency} إلى ${address.substring(0, 8)}...`,
        status: "completed",
      });
      return true;
    },
    [wallet, exchangeRates, addTransaction]
  );

  return (
    <WalletContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isRTL,
        wallet,
        cards,
        transactions,
        exchangeRates,
        refreshWallet,
        addCard,
        removeCard,
        setDefaultCard,
        freezeCard,
        addTransaction,
        depositFunds,
        transferLocal,
        exchangeCurrency,
        transferCrypto,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}
