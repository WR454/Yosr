import * as LocalAuthentication from "expo-local-authentication";
import * as SecureStore from "expo-secure-store";
import CryptoJS from "crypto-js";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { AppState, Platform } from "react-native";

export type SecurityLevel = "unlocked" | "locked" | "biometric_required";

interface OtpSession {
  code: string;
  expiresAt: number;
  purpose: string;
  attempts: number;
}

export interface SecurityLog {
  type: string;
  timestamp: string;
  details?: string;
}

interface SecurityContextType {
  isLocked: boolean;
  isBiometricAvailable: boolean;
  isBiometricEnrolled: boolean;
  unlockWithBiometric: () => Promise<boolean>;
  lockApp: () => void;
  generateOtp: (purpose: string) => Promise<string>;
  verifyOtp: (code: string) => boolean;
  clearOtp: () => void;
  otpPurpose: string | null;
  otpExpiresAt: number | null;
  securityLogs: SecurityLog[];
  encryptSensitive: (value: string) => string;
  decryptSensitive: (encrypted: string) => string;
  storeSecure: (key: string, value: string) => Promise<void>;
  getSecure: (key: string) => Promise<string | null>;
}

const SecurityContext = createContext<SecurityContextType | null>(null);

const OTP_TTL_MS = 3 * 60 * 1000;
const AUTO_LOCK_MS = 5 * 60 * 1000;
const AES_SECRET = "saudi-wallet-aes256-key-secure!!";

function cryptoJsEncrypt(value: string): string {
  const encrypted = CryptoJS.AES.encrypt(value, AES_SECRET).toString();
  return `enc:${encrypted}`;
}

function cryptoJsDecrypt(ciphertext: string): string {
  if (!ciphertext.startsWith("enc:")) return ciphertext;
  const raw = ciphertext.slice(4);
  const bytes = CryptoJS.AES.decrypt(raw, AES_SECRET);
  return bytes.toString(CryptoJS.enc.Utf8);
}

function cryptoJsHash(value: string): string {
  return CryptoJS.SHA256(value).toString(CryptoJS.enc.Hex);
}

function encryptLogEntry(entry: SecurityLog): string {
  const json = JSON.stringify(entry);
  return CryptoJS.AES.encrypt(json, AES_SECRET).toString();
}

function generateSecureRandom6Digit(): string {
  try {
    const array = new Uint8Array(3);
    globalThis.crypto.getRandomValues(array);
    const num = ((array[0] << 16) | (array[1] << 8) | array[2]) % 1000000;
    return num.toString().padStart(6, "0");
  } catch {
    const num = Math.floor(Math.random() * 1000000);
    return num.toString().padStart(6, "0");
  }
}

export function SecurityProvider({ children }: { children: React.ReactNode }) {
  const [isLocked, setIsLocked] = useState(false);
  const [isBiometricAvailable, setIsBiometricAvailable] = useState(false);
  const [isBiometricEnrolled, setIsBiometricEnrolled] = useState(false);
  const [otpSession, setOtpSession] = useState<OtpSession | null>(null);
  const [securityLogs, setSecurityLogs] = useState<SecurityLog[]>([]);
  const lastActiveRef = useRef(Date.now());

  useEffect(() => {
    initBiometric();
    const cleanup = setupAutoLock();
    return cleanup;
  }, []);

  const initBiometric = async () => {
    if (Platform.OS === "web") return;
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      setIsBiometricAvailable(hasHardware);
      setIsBiometricEnrolled(enrolled);
    } catch (_) {}
  };

  const setupAutoLock = () => {
    const sub = AppState.addEventListener("change", (state) => {
      if (state === "active") {
        const elapsed = Date.now() - lastActiveRef.current;
        if (elapsed > AUTO_LOCK_MS) {
          setIsLocked(true);
          addLog("auto_lock", "App auto-locked after inactivity");
        }
      } else {
        lastActiveRef.current = Date.now();
      }
    });
    return () => sub.remove();
  };

  const addLog = useCallback((type: string, details?: string) => {
    const entry: SecurityLog = {
      type,
      timestamp: new Date().toISOString(),
      details,
    };
    setSecurityLogs((prev) => [entry, ...prev].slice(0, 100));

    if (Platform.OS !== "web") {
      try {
        const encrypted = encryptLogEntry(entry);
        SecureStore.setItemAsync("sec_audit_log", encrypted).catch(() => {});
      } catch (_) {}
    }
  }, []);

  const unlockWithBiometric = useCallback(async (): Promise<boolean> => {
    if (Platform.OS === "web") {
      setIsLocked(false);
      addLog("biometric_skip", "Biometric skipped on web platform");
      return true;
    }
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: "Verify your identity",
        fallbackLabel: "Use Passcode",
        cancelLabel: "Cancel",
        disableDeviceFallback: false,
      });
      if (result.success) {
        setIsLocked(false);
        addLog("biometric_success", "Biometric authentication succeeded");
        return true;
      }
      addLog("biometric_failure", `Biometric failed: ${result.error}`);
      return false;
    } catch (err) {
      addLog("biometric_error", String(err));
      return false;
    }
  }, [addLog]);

  const lockApp = useCallback(() => {
    setIsLocked(true);
    addLog("manual_lock", "App manually locked");
  }, [addLog]);

  const generateOtp = useCallback(
    async (purpose: string): Promise<string> => {
      const code = generateSecureRandom6Digit();
      const session: OtpSession = {
        code,
        expiresAt: Date.now() + OTP_TTL_MS,
        purpose,
        attempts: 0,
      };
      setOtpSession(session);
      addLog("otp_generated", `OTP generated for: ${purpose}`);
      return code;
    },
    [addLog]
  );

  const verifyOtp = useCallback(
    (inputCode: string): boolean => {
      if (!otpSession) {
        addLog("otp_verify_fail", "No active OTP session");
        return false;
      }
      if (Date.now() > otpSession.expiresAt) {
        addLog("otp_expired", `OTP expired for: ${otpSession.purpose}`);
        setOtpSession(null);
        return false;
      }
      if (otpSession.attempts >= 3) {
        addLog("otp_blocked", "Max OTP attempts reached");
        setOtpSession(null);
        return false;
      }
      if (inputCode.trim() === otpSession.code) {
        addLog("otp_success", `OTP verified for: ${otpSession.purpose}`);
        setOtpSession(null);
        return true;
      }
      const newAttempts = otpSession.attempts + 1;
      setOtpSession((prev) =>
        prev ? { ...prev, attempts: newAttempts } : null
      );
      addLog("otp_wrong_code", `Wrong OTP attempt ${newAttempts}/3`);
      return false;
    },
    [otpSession, addLog]
  );

  const clearOtp = useCallback(() => {
    setOtpSession(null);
  }, []);

  const encryptSensitive = useCallback((value: string): string => {
    try {
      return cryptoJsEncrypt(value);
    } catch {
      return value;
    }
  }, []);

  const decryptSensitive = useCallback((encrypted: string): string => {
    try {
      return cryptoJsDecrypt(encrypted);
    } catch {
      return encrypted;
    }
  }, []);

  const storeSecure = useCallback(async (key: string, value: string): Promise<void> => {
    const encryptedValue = cryptoJsEncrypt(value);
    if (Platform.OS === "web") {
      try { sessionStorage.setItem(`secure_${key}`, encryptedValue); } catch (_) {}
      return;
    }
    try {
      await SecureStore.setItemAsync(key, encryptedValue, {
        keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
      });
    } catch (_) {}
  }, []);

  const getSecure = useCallback(async (key: string): Promise<string | null> => {
    let raw: string | null = null;
    if (Platform.OS === "web") {
      try { raw = sessionStorage.getItem(`secure_${key}`); } catch (_) {}
    } else {
      try { raw = await SecureStore.getItemAsync(key); } catch (_) {}
    }
    if (!raw) return null;
    try { return cryptoJsDecrypt(raw); } catch { return raw; }
  }, []);

  return (
    <SecurityContext.Provider
      value={{
        isLocked,
        isBiometricAvailable,
        isBiometricEnrolled,
        unlockWithBiometric,
        lockApp,
        generateOtp,
        verifyOtp,
        clearOtp,
        otpPurpose: otpSession?.purpose ?? null,
        otpExpiresAt: otpSession?.expiresAt ?? null,
        securityLogs,
        encryptSensitive,
        decryptSensitive,
        storeSecure,
        getSecure,
      }}
    >
      {children}
    </SecurityContext.Provider>
  );
}

export function useSecurity() {
  const ctx = useContext(SecurityContext);
  if (!ctx) throw new Error("useSecurity must be used within SecurityProvider");
  return ctx;
}
