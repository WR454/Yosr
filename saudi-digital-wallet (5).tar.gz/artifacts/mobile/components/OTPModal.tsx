import { Feather, Ionicons } from "@expo/vector-icons";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Alert,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import Colors from "@/constants/colors";
import { useSecurity } from "@/context/SecurityContext";
import { useWallet } from "@/context/WalletContext";

interface OTPModalProps {
  visible: boolean;
  purpose: string;
  purposeAr?: string;
  amount?: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function OTPModal({
  visible,
  purpose,
  purposeAr,
  amount,
  onSuccess,
  onCancel,
}: OTPModalProps) {
  const { generateOtp, verifyOtp, clearOtp, otpExpiresAt } = useSecurity();
  const { t } = useWallet();
  const [code, setCode] = useState("");
  const [otpCode, setOtpCode] = useState<string | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(180);
  const [attempts, setAttempts] = useState(0);
  const inputRef = useRef<TextInput>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startOtp = useCallback(async () => {
    const generated = await generateOtp(purpose);
    setOtpCode(generated);
    setCode("");
    setAttempts(0);
    setSecondsLeft(180);
    setTimeout(() => inputRef.current?.focus(), 300);
  }, [generateOtp, purpose]);

  useEffect(() => {
    if (visible) {
      startOtp();
    } else {
      clearOtp();
      setOtpCode(null);
      setCode("");
    }
  }, [visible]);

  useEffect(() => {
    if (!visible) return;
    timerRef.current = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(timerRef.current!);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [visible, otpCode]);

  const handleVerify = () => {
    if (secondsLeft === 0) {
      Alert.alert(
        t("OTP Expired", "انتهت صلاحية الرمز"),
        t("Request a new OTP to continue.", "اطلب رمزاً جديداً للمتابعة.")
      );
      return;
    }
    const ok = verifyOtp(code);
    if (ok) {
      Keyboard.dismiss();
      onSuccess();
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      if (newAttempts >= 3) {
        Alert.alert(
          t("Too Many Attempts", "محاولات كثيرة"),
          t("Verification blocked. Try again later.", "تم حظر التحقق. حاول مرة أخرى لاحقاً."),
          [{ text: "OK", onPress: onCancel }]
        );
      } else {
        Alert.alert(
          t("Incorrect Code", "رمز خاطئ"),
          t(
            `Wrong OTP. ${3 - newAttempts} attempt(s) remaining.`,
            `رمز خاطئ. متبقٍ ${3 - newAttempts} محاولة/محاولات.`
          )
        );
        setCode("");
      }
    }
  };

  const handleResend = () => {
    startOtp();
  };

  const formatTime = (s: number) =>
    `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  const purposeLabel = t(purpose, purposeAr || purpose);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onCancel}
    >
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <Pressable style={styles.backdrop} onPress={Keyboard.dismiss} />
        <View style={styles.sheet}>
          {/* Header */}
          <View style={styles.sheetHeader}>
            <View style={styles.shieldIcon}>
              <Ionicons name="shield-checkmark" size={28} color={Colors.light.tint} />
            </View>
            <Pressable style={styles.closeBtn} onPress={onCancel}>
              <Feather name="x" size={20} color={Colors.light.textSecondary} />
            </Pressable>
          </View>

          <Text style={styles.title}>{t("Two-Step Verification", "التحقق بخطوتين")}</Text>
          <Text style={styles.subtitle}>
            {t(
              "A 6-digit verification code has been sent to your registered mobile number.",
              "تم إرسال رمز تحقق مكون من 6 أرقام إلى رقم هاتفك المسجل."
            )}
          </Text>

          {amount !== undefined && (
            <View style={styles.amountBadge}>
              <Feather name="alert-circle" size={14} color={Colors.light.gold} />
              <Text style={styles.amountBadgeText}>
                {t("Transfer Amount:", "مبلغ التحويل:")} {amount.toLocaleString("en-SA", { minimumFractionDigits: 2 })} SAR
              </Text>
            </View>
          )}

          <Text style={styles.purposeLabel}>{purposeLabel}</Text>

          {/* OTP Preview (dev mode only) */}
          {__DEV__ && otpCode && (
            <View style={styles.devBanner}>
              <Feather name="terminal" size={12} color="#92400E" />
              <Text style={styles.devText}>
                {t("Dev mode — OTP:", "وضع التطوير — الرمز:")} {otpCode}
              </Text>
            </View>
          )}

          {/* OTP Input */}
          <TextInput
            ref={inputRef}
            style={styles.otpInput}
            value={code}
            onChangeText={(v) => setCode(v.replace(/\D/g, "").slice(0, 6))}
            placeholder="••••••"
            placeholderTextColor={Colors.light.textMuted}
            keyboardType="number-pad"
            maxLength={6}
            textAlign="center"
            autoComplete="one-time-code"
            textContentType="oneTimeCode"
          />

          {/* Timer */}
          <View style={styles.timerRow}>
            <Feather
              name="clock"
              size={14}
              color={secondsLeft < 30 ? Colors.light.error : Colors.light.textMuted}
            />
            <Text
              style={[
                styles.timerText,
                secondsLeft < 30 && { color: Colors.light.error },
              ]}
            >
              {secondsLeft > 0
                ? `${t("Expires in", "تنتهي خلال")} ${formatTime(secondsLeft)}`
                : t("Code expired", "انتهت صلاحية الرمز")}
            </Text>
          </View>

          {/* Verify Button */}
          <Pressable
            style={({ pressed }) => [
              styles.verifyBtn,
              { opacity: pressed || code.length < 6 ? 0.7 : 1 },
            ]}
            onPress={handleVerify}
            disabled={code.length < 6}
          >
            <Ionicons name="checkmark-circle" size={20} color="#fff" />
            <Text style={styles.verifyBtnText}>{t("Verify & Continue", "تحقق وتابع")}</Text>
          </Pressable>

          {/* Resend */}
          <Pressable
            style={styles.resendBtn}
            onPress={handleResend}
            disabled={secondsLeft > 150}
          >
            <Feather name="refresh-cw" size={14} color={secondsLeft > 150 ? Colors.light.textMuted : Colors.light.tint} />
            <Text
              style={[
                styles.resendText,
                secondsLeft > 150 && { color: Colors.light.textMuted },
              ]}
            >
              {t("Resend OTP", "إعادة إرسال الرمز")}
            </Text>
          </Pressable>

          {/* Security footer */}
          <View style={styles.securityFooter}>
            <Ionicons name="lock-closed" size={12} color={Colors.light.textMuted} />
            <Text style={styles.securityFooterText}>
              {t(
                "Secured by AES-256 encryption",
                "مؤمّن بتشفير AES-256"
              )}
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "flex-end",
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  sheet: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 24,
    paddingBottom: 40,
    paddingTop: 8,
  },
  sheetHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingTop: 16,
    marginBottom: 12,
  },
  shieldIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.light.tint + "15",
    alignItems: "center",
    justifyContent: "center",
  },
  closeBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: "#F3F4F6",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    color: "#0F1E14",
    fontFamily: "Inter_700Bold",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: "#4A6355",
    fontFamily: "Inter_400Regular",
    lineHeight: 20,
    marginBottom: 16,
  },
  amountBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#FEF3C7",
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
  },
  amountBadgeText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#92400E",
    fontFamily: "Inter_600SemiBold",
  },
  purposeLabel: {
    fontSize: 13,
    color: "#8BA396",
    fontFamily: "Inter_400Regular",
    marginBottom: 16,
  },
  devBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#FEF3C7",
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
  },
  devText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#92400E",
    fontFamily: "Inter_700Bold",
    letterSpacing: 2,
  },
  otpInput: {
    backgroundColor: "#F5F8F6",
    borderRadius: 16,
    paddingVertical: 20,
    fontSize: 32,
    fontWeight: "700",
    color: "#0F1E14",
    fontFamily: "Inter_700Bold",
    borderWidth: 2,
    borderColor: Colors.light.tint + "40",
    letterSpacing: 12,
    marginBottom: 12,
    textAlign: "center",
  },
  timerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    marginBottom: 20,
  },
  timerText: {
    fontSize: 13,
    color: "#8BA396",
    fontFamily: "Inter_400Regular",
  },
  verifyBtn: {
    backgroundColor: Colors.light.tint,
    borderRadius: 16,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    marginBottom: 12,
  },
  verifyBtnText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "Inter_700Bold",
  },
  resendBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 12,
    marginBottom: 16,
  },
  resendText: {
    fontSize: 14,
    color: Colors.light.tint,
    fontFamily: "Inter_600SemiBold",
  },
  securityFooter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
  },
  securityFooterText: {
    fontSize: 11,
    color: "#8BA396",
    fontFamily: "Inter_400Regular",
  },
});
