import type { NextFunction, Request, Response } from "express";
import rateLimit from "express-rate-limit";
import { isIpLocked, logSecurityEvent, recordFailedAttempt } from "../lib/security-logger.js";

const SQL_INJECTION_PATTERNS = [
  /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|TRUNCATE)\b)/i,
  /(--|;|\/\*|\*\/|xp_|sp_)/,
  /('|('')|(")|(\\")|(\\')|(%27)|(%22))/,
  /(0x[0-9a-f]+)/i,
  /(\bOR\b\s+\d+\s*=\s*\d+)/i,
  /(\bAND\b\s+\d+\s*=\s*\d+)/i,
  /(\bWHERE\b.*=.*--)/i,
];

const XSS_PATTERNS = [
  /<script[\s\S]*?>[\s\S]*?<\/script>/gi,
  /javascript:/gi,
  /on\w+\s*=/gi,
  /<[^>]*\s(on\w+)\s*=/gi,
];

function detectSqlInjection(value: string): boolean {
  return SQL_INJECTION_PATTERNS.some((pattern) => pattern.test(value));
}

function detectXss(value: string): boolean {
  return XSS_PATTERNS.some((pattern) => pattern.test(value));
}

function scanObject(obj: unknown): boolean {
  if (typeof obj === "string") {
    return detectSqlInjection(obj) || detectXss(obj);
  }
  if (typeof obj === "object" && obj !== null) {
    return Object.values(obj).some((v) => scanObject(v));
  }
  return false;
}

export const globalRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    const ip = req.ip || "unknown";
    logSecurityEvent({
      type: "rate_limit_block",
      ip,
      details: { path: req.path, method: req.method },
    });
    res.status(429).json({
      error: "Too many requests",
      message: "Rate limit exceeded. Please try again later.",
      retryAfter: 60,
    });
  },
});

export const authRateLimit = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    const ip = req.ip || "unknown";
    logSecurityEvent({
      type: "brute_force_block",
      ip,
      details: { path: req.path },
    });
    res.status(429).json({
      error: "Too many authentication attempts",
      message: "Account temporarily locked. Try again in 5 minutes.",
    });
  },
});

export const transferRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    const ip = req.ip || "unknown";
    logSecurityEvent({
      type: "rate_limit_block",
      ip,
      details: { path: "/transfer", method: req.method },
    });
    res.status(429).json({
      error: "Transfer rate limit exceeded",
      message: "Too many transfer requests. Please wait before retrying.",
    });
  },
});

export function wafMiddleware(req: Request, res: Response, next: NextFunction): void {
  const ip = req.ip || "unknown";

  if (isIpLocked(ip)) {
    logSecurityEvent({
      type: "brute_force_block",
      ip,
      details: { reason: "IP locked due to repeated failures" },
    });
    res.status(403).json({
      error: "Access denied",
      message: "Your IP has been temporarily blocked due to suspicious activity.",
    });
    return;
  }

  const payloads: unknown[] = [req.body, req.query, req.params];
  for (const payload of payloads) {
    if (payload && scanObject(payload)) {
      logSecurityEvent({
        type: "waf_sql_injection",
        ip,
        details: {
          path: req.path,
          method: req.method,
          threat: "SQL injection or XSS detected",
        },
      });
      res.status(400).json({
        error: "Malicious payload detected",
        message: "Request blocked by security firewall.",
      });
      return;
    }
  }

  const suspiciousHeaders = ["x-forwarded-for", "x-real-ip"];
  for (const header of suspiciousHeaders) {
    const val = req.headers[header];
    if (val && typeof val === "string" && detectSqlInjection(val)) {
      logSecurityEvent({
        type: "waf_suspicious_payload",
        ip,
        details: { header, threat: "Injection in header" },
      });
      res.status(400).json({ error: "Malicious header detected" });
      return;
    }
  }

  next();
}

export function bruteForceGuard(req: Request, res: Response, next: NextFunction): void {
  const ip = req.ip || "unknown";
  const { blocked, attemptsLeft } = recordFailedAttempt(ip);
  if (blocked) {
    logSecurityEvent({
      type: "brute_force_block",
      ip,
      details: { reason: "Max login attempts exceeded" },
    });
    res.status(403).json({
      error: "Account locked",
      message: "Too many failed attempts. Account locked for 15 minutes.",
      attemptsLeft: 0,
    });
    return;
  }
  (req as Request & { attemptsLeft: number }).attemptsLeft = attemptsLeft;
  next();
}
