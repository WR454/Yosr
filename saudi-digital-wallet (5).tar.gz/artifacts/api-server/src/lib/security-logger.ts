import crypto from "crypto";
import fs from "fs";
import path from "path";
import { logger } from "./logger.js";

export type SecurityEventType =
  | "2fa_attempt"
  | "2fa_success"
  | "2fa_failure"
  | "brute_force_block"
  | "rate_limit_block"
  | "waf_sql_injection"
  | "waf_suspicious_payload"
  | "login_attempt"
  | "login_success"
  | "login_failure"
  | "high_value_transfer"
  | "account_locked";

export interface SecurityEvent {
  type: SecurityEventType;
  ip: string;
  userId?: string;
  details?: Record<string, unknown>;
  timestamp: string;
}

const LOG_KEY = crypto
  .createHash("sha256")
  .update(process.env["ENCRYPTION_KEY"] || "audit-log-key-32bytes-default!!")
  .digest();

const LOG_DIR = path.join(process.cwd(), "logs");

function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
}

function encryptLogEntry(entry: SecurityEvent): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", LOG_KEY, iv) as crypto.CipherGCM;
  const data = JSON.stringify(entry);
  const encrypted = Buffer.concat([cipher.update(data, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]).toString("base64");
}

export function logSecurityEvent(event: Omit<SecurityEvent, "timestamp">): void {
  const entry: SecurityEvent = {
    ...event,
    timestamp: new Date().toISOString(),
  };

  logger.info(
    { security: true, type: entry.type, ip: entry.ip, userId: entry.userId },
    `[SECURITY] ${entry.type}`
  );

  try {
    ensureLogDir();
    const logFile = path.join(LOG_DIR, "security-audit.log");
    const encryptedLine = encryptLogEntry(entry) + "\n";
    fs.appendFileSync(logFile, encryptedLine, "utf8");
  } catch (err) {
    logger.error({ err }, "Failed to write security audit log");
  }
}

const failedAttempts = new Map<string, { count: number; lockedUntil?: number }>();

export function recordFailedAttempt(ip: string): {
  blocked: boolean;
  attemptsLeft: number;
} {
  const MAX_ATTEMPTS = 3;
  const LOCK_DURATION_MS = 15 * 60 * 1000;
  const now = Date.now();
  const record = failedAttempts.get(ip) || { count: 0 };

  if (record.lockedUntil && now < record.lockedUntil) {
    return { blocked: true, attemptsLeft: 0 };
  }

  record.count++;
  if (record.count >= MAX_ATTEMPTS) {
    record.lockedUntil = now + LOCK_DURATION_MS;
    failedAttempts.set(ip, record);
    logSecurityEvent({ type: "account_locked", ip, details: { attempts: record.count } });
    return { blocked: true, attemptsLeft: 0 };
  }

  failedAttempts.set(ip, record);
  return { blocked: false, attemptsLeft: MAX_ATTEMPTS - record.count };
}

export function clearFailedAttempts(ip: string): void {
  failedAttempts.delete(ip);
}

export function isIpLocked(ip: string): boolean {
  const record = failedAttempts.get(ip);
  if (!record?.lockedUntil) return false;
  if (Date.now() >= record.lockedUntil) {
    failedAttempts.delete(ip);
    return false;
  }
  return true;
}
