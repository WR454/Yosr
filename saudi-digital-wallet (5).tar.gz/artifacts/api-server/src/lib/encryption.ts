import CryptoJS from "crypto-js";

const AES_SECRET =
  process.env["ENCRYPTION_KEY"] || "saudi-wallet-aes256-key-secure!!";

export function encrypt(plaintext: string): string {
  return CryptoJS.AES.encrypt(plaintext, AES_SECRET).toString();
}

export function decrypt(ciphertext: string): string {
  const bytes = CryptoJS.AES.decrypt(ciphertext, AES_SECRET);
  return bytes.toString(CryptoJS.enc.Utf8);
}

export function hashField(value: string): string {
  return CryptoJS.SHA256(value).toString(CryptoJS.enc.Hex);
}

export function maskIban(iban: string): string {
  if (iban.length < 8) return "****";
  return iban.substring(0, 4) + "****" + iban.substring(iban.length - 4);
}

export function maskCardNumber(num: string): string {
  return "**** **** **** " + num.slice(-4);
}
